﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _13._2
{
    //Proxy patterns
    interface IBanka
    {
        bool OdemeYap(double Tutar);
    }

    class Banka : IBanka
    {
        public bool OdemeYap(double Tutar)
        {
            if(Tutar<100)
            {
                Console.WriteLine($"Ödemek istediğiniz tutar 100 tl ve yukarısında olmalıdır, Ödenmek istenen tutar {Tutar} Fark {100-Tutar}");
                return false;
            }
            else
            {
                Console.WriteLine($"Ödeme başarılı: {Tutar}");
                return false;
            }
        }
    }

    //Proxy Class


    class ProxyBanka : IBanka
    {
        Banka banka;
        bool Login;
        string kullaniciAdi;
        string sifre;
        string ip;

        public ProxyBanka(string KullaniciAdi, string KullaniciSifre, string IpKontrol)
        {
            kullaniciAdi = KullaniciAdi;
            sifre = KullaniciSifre;
            ip= IpKontrol;
        }
        bool GirisYap()
        {
            if (kullaniciAdi == "ayse" && sifre == "123456" && ip == "127.0.0.1") 
            {
                banka=new Banka();
                Login = true;
                return true;
            }
            else
            {
                Login = false;
                return false;
            }
        }

        public bool OdemeYap(double Tutar)
        {
            GirisYap();
            if(Login)
            {
                banka.OdemeYap(Tutar);
                return true;
            }
            else
            {
                Console.WriteLine("Hesaba Giriş Yapılamadığından Ödeme Alınamadı");
                return false;
            }
        }
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            String Kullanici = "";
            String Sifre = "";
            double Tutar = 0;

            while(true)
            {
                Console.WriteLine("Lütfen kullanici adınızı giriniz");
                Kullanici=Console.ReadLine();

                Console.WriteLine("Lütfen Sifrenizi giriniz");
                Sifre=Console.ReadLine();

                Console.WriteLine("Tutarı giriniz, en düşük 100 tl");
                Tutar=double.Parse(Console.ReadLine());
                IBanka banka = new ProxyBanka(Kullanici,Sifre,"127.0.0.1");
                banka.OdemeYap(Tutar);

                Console.WriteLine("-----------");
            
            }
        }
    }
}
