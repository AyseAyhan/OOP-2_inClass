﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

//13.1, bu dosya= Iterator pattern
//13.2 adapter pattern ve proxy pattern
//Iterator
namespace _13._1
{
    struct Personel
    {
        public int Id { get; set;}
        public string Adi { get; set; }
        public string Soyadi { get; set; }
    }

    interface IAggregate
    {
        Iterator CreateIterator();
    }

    interface Iterator
    {
        bool HasItem();
        Personel NxtItem();
        Personel CurrentItem();
    }

    class PersonelAggregate:IAggregate
    {
        List<Personel> PersonelList=new List<Personel>();
        public void Add(Personel personel) => PersonelList.Add(personel);

        public Personel GetItem(int index) => PersonelList[index];
        public int Count { get=>PersonelList.Count;}

        public Iterator CreateIterator() => new PersonelIterator(this);
    
    }


    class PersonelIterator : Iterator
    {
        PersonelAggregate aggregate;
        int currentindex;
        public PersonelIterator(PersonelAggregate aggregate)=> this.aggregate = aggregate;
        public Personel CurrentItem() => aggregate.GetItem(currentindex);
        
        public bool HasItem()
        {
            if (currentindex < aggregate.Count)
                return true;
            return false;
        }
    
        public Personel NxtItem()
        {
            if(HasItem())
                return aggregate.GetItem(currentindex++);
            return new Personel();
        }

    }


    internal class Program
    {
        static void Main(string[] args)
        {
            PersonelAggregate aggregate = new PersonelAggregate();
            aggregate.Add(new Personel { Id = 1, Adi = "Ayse",Soyadi="Ayhan" });
            aggregate.Add(new Personel { Id = 10, Adi = "Ayse", Soyadi = "Ayhan" });
            aggregate.Add(new Personel { Id = 100, Adi = "Ayse", Soyadi = "Ayhan" });
            
            Iterator iterator=aggregate.CreateIterator();
             while(iterator.HasItem())
            {
               Console.WriteLine($"Id:{iterator.CurrentItem().Id}, Ad: {iterator.CurrentItem().Adi}, Soyad: {iterator.CurrentItem().Soyadi}");
               iterator.NxtItem();
            }
            Console.ReadLine();
        }
    }

    }
    
