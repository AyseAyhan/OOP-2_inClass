﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace _13._3
{
    //Adapter Pattern
    //bir kaynaktaki bir yapıyı başka yapıya uyarlar


    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Department { get; set; }
        public decimal Salary { get; set; }

        public Employee(int id, string name, string department, decimal salary)
        {
            Id = id;
            Name = name;
            Department = department;
            Salary = salary;     
        }
    }

    public class ThidrPartyBillingSystem
    {
        public void ProcessSalary(List<Employee> employees)
        {
            foreach (Employee employee in employees)
            {
                Console.WriteLine($"Id:{employee.Id}, \tName:{employee.Name}, \tDepartment:{employee.Department}, \tSalary:{employee.Salary}");
            }
        }

    }


    public interface ITarget
    {
        void ProcessCompanySalary(String[,] employeesArray);
    }

    //adaptor

    public class EmployeeAdaptor : ITarget
    {
        ThidrPartyBillingSystem ThirdPartyBillingSystem =new ThidrPartyBillingSystem();
        
        public void ProcessCompanySalary(string[,] employeesArray)
        {
            string Id = "";
            string Name = "";
            string Department = "";
            string Salary = "";
            List<Employee> list_Emp = new List<Employee>();
            for(int i=0; i<employeesArray.GetLength(0); i++)
            {
                for(int j=0;j<employeesArray.GetLength(1); j++)
                {
                    if(j==0)
                    {
                        Id = employeesArray[i,j];
                    }
                    else if(j==1)
                    {
                        Name= employeesArray[i,j];
                    }
                    else if(j==2)
                    {
                        Department= employeesArray[i,j];
                    }
                    else
                    {
                        Salary= employeesArray[i,j];
                    }
                }
                list_Emp.Add(new Employee(int.Parse(Id), Name, Department, decimal.Parse(Salary)));
            }
            ThirdPartyBillingSystem.ProcessSalary(list_Emp);  
        }
    }



    internal class Program
    {
        static void Main(string[] args)
        {
            string[,] employee_Array = new string[5, 4]
            {
                //5 TANE OLMALI
                { "1","Ayse","IT","100.000" },
                { "2","Bjorn","BT","120.000" },
                { "3","Noah","IT","50.000" },
                { "4","Eskild","BT","90.000" },
                { "5","Logan","IT","100.000" },
            };

            ITarget target = new EmployeeAdaptor();
            target.ProcessCompanySalary(employee_Array);
            Console.ReadLine();
        }
    }
}
