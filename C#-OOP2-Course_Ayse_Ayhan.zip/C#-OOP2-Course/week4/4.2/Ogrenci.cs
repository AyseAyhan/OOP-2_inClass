﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4._2
{
    internal class Ogrenci
    {
        public Ogrenci(string OgrAd, string OgrSoyad, int Age)   //constructor
        {
            ogrAd = OgrAd;
            ogrSoyad = OgrSoyad;
            age = Age;
        }


        //c#>add new item>class
        private string ogrAd;

        public string OgrAd {
            get { return ogrAd; }
            set { ogrAd= value; }
        }

        private string ogrSoyad;
        public string OgrSoyad
        {
            get { return ogrSoyad; }
            set { ogrSoyad = value; }
        }

        private int age;
        public int Age
        {
            get { return age; }
            set { age = value; }
        }
    }
}
