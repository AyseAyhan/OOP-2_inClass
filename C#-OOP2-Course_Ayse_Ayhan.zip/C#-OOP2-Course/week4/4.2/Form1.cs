﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4._2
{
    //çok büyük verilerle çalışmıyorsa otomatik garbage collector işe yarar
    public partial class Form1 : Form
    {
        int[] int_dizi=new int[5];  //out of scope hatası vermemesi için global tanımla
        Ogrenci[] ogr_dizi;
       // Ogrenci ogrenci;  //nesneye gerek yok, dizi üzerinden erişilebilir
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            ogr_dizi= new Ogrenci[3];
            //int[] int_dizi = new int[5];
            double[] int_dizi2 = { 11, 12, 13, 14, 15 };
            //int_dizi= new int { 111, 222, 333, 444, 555 };
            for (int i = 0; i < int_dizi2.Length; i++)
            {
                text_out.Text += Environment.NewLine + "Dizinin " + i + ". Elemanı: " + int_dizi[i];
            }
        }
        private void button_listele_Click(object sender, EventArgs e)
        {
            //sındavda dizinin max boyutu, eleman sayısını isterse .length gibi hazır fonksiyonlar kullanma
            //!!!önemli: başka bir scope'ta not exist context yani out of scope hatası vermemesi için global tanımlanmalıdır
            int_dizi[0] = 1;
            int_dizi[1] = 2;
            int_dizi[2] = 3;
            int_dizi[3] = 4;
            int_dizi[4] = 5;
            for (int i = 0; i < int_dizi.Length; i++)
            {
                //int_dizi[i] += 1;
                text_out.Text += Environment.NewLine+"Dizinin " + i + ". Elemanı: " + int_dizi[i];
            }
        }
        private void button_ch_Click(object sender, EventArgs e)
        {
            int_dizi[1] = 234;
           // int_dizi[2] = 99; çalıştıktan sonra hata verir    dizi boş olduğu için, dizi tanımını loada ya da globala koy
            text_out.Text +=Environment.NewLine+ "_____________________DEĞİŞTİ___________________";
            for (int i = 0; i < int_dizi.Length; i++)
            {
                //int_dizi[i] += 1;
                text_out.Text += Environment.NewLine+"Dizinin " + i + ". Elemanı: " + int_dizi[i];
            }
        }

        private void btn_snf_Click(object sender, EventArgs e)
        {
            text_out.Text = " ";
            ogr_dizi[0] = new Ogrenci("Ayse", "Ayhan", 21);
            ogr_dizi[1] = new Ogrenci("Mona", "Lisa", 27);
            ogr_dizi[2] = new Ogrenci("Edward", "Munch", 130);
            for (int i=0;i<ogr_dizi.Length;i++)
            {   //+ gerekli, üzerine yazmak yerine eklemesi için
                text_out.Text+= Environment.NewLine + i + ". Ogrenci Bilgileri: " + ogr_dizi[i].OgrAd + "\t" + ogr_dizi[i].OgrSoyad + "\t" + ogr_dizi[i].Age;
            }
        }
        private void button_chg_Click(object sender, EventArgs e)
        {
            ogr_dizi[1].OgrAd = "MON";
            text_out.Text += Environment.NewLine + "___________Değişti____________" + Environment.NewLine;
            for (int i = 0; i < ogr_dizi.Length; i++)
            {   //+ gerekli, üzerine yazmak yerine eklemesi için
                text_out.Text += Environment.NewLine + i + ". Ogrenci Bilgileri: " + ogr_dizi[i].OgrAd + "\t" + ogr_dizi[i].OgrSoyad + "\t" + ogr_dizi[i].Age;
            }
        }

        private void button_fr_Click(object sender, EventArgs e)
        {
            text_out.Text = string.Empty;
            foreach(Ogrenci ogr in ogr_dizi)  //önemli /class nesne dizi/
            {
                text_out.Text += ogr.OgrAd + "\t" + ogr.OgrSoyad + "\t" + ogr.Age + Environment.NewLine;
            }
        }
    }

}