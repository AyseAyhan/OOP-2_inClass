﻿namespace _4._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_listele = new System.Windows.Forms.Button();
            this.text_out = new System.Windows.Forms.TextBox();
            this.button_ch = new System.Windows.Forms.Button();
            this.btn_snf = new System.Windows.Forms.Button();
            this.button_chg = new System.Windows.Forms.Button();
            this.button_fr = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_listele
            // 
            this.button_listele.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_listele.Location = new System.Drawing.Point(28, 35);
            this.button_listele.Name = "button_listele";
            this.button_listele.Size = new System.Drawing.Size(143, 49);
            this.button_listele.TabIndex = 0;
            this.button_listele.Text = "Listele";
            this.button_listele.UseVisualStyleBackColor = true;
            this.button_listele.Click += new System.EventHandler(this.button_listele_Click);
            // 
            // text_out
            // 
            this.text_out.Location = new System.Drawing.Point(232, 35);
            this.text_out.Multiline = true;
            this.text_out.Name = "text_out";
            this.text_out.Size = new System.Drawing.Size(332, 403);
            this.text_out.TabIndex = 1;
            // 
            // button_ch
            // 
            this.button_ch.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_ch.Location = new System.Drawing.Point(28, 103);
            this.button_ch.Name = "button_ch";
            this.button_ch.Size = new System.Drawing.Size(142, 46);
            this.button_ch.TabIndex = 2;
            this.button_ch.Text = "Değiştir";
            this.button_ch.UseVisualStyleBackColor = true;
            this.button_ch.Click += new System.EventHandler(this.button_ch_Click);
            // 
            // btn_snf
            // 
            this.btn_snf.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_snf.Location = new System.Drawing.Point(590, 35);
            this.btn_snf.Name = "btn_snf";
            this.btn_snf.Size = new System.Drawing.Size(198, 64);
            this.btn_snf.TabIndex = 3;
            this.btn_snf.Text = "Sınıf Listesi";
            this.btn_snf.UseVisualStyleBackColor = true;
            this.btn_snf.Click += new System.EventHandler(this.btn_snf_Click);
            // 
            // button_chg
            // 
            this.button_chg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_chg.Location = new System.Drawing.Point(590, 105);
            this.button_chg.Name = "button_chg";
            this.button_chg.Size = new System.Drawing.Size(198, 64);
            this.button_chg.TabIndex = 4;
            this.button_chg.Text = "Liste Değiştir";
            this.button_chg.UseVisualStyleBackColor = true;
            this.button_chg.Click += new System.EventHandler(this.button_chg_Click);
            // 
            // button_fr
            // 
            this.button_fr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button_fr.Location = new System.Drawing.Point(590, 185);
            this.button_fr.Name = "button_fr";
            this.button_fr.Size = new System.Drawing.Size(198, 64);
            this.button_fr.TabIndex = 5;
            this.button_fr.Text = "FOREACH";
            this.button_fr.UseVisualStyleBackColor = true;
            this.button_fr.Click += new System.EventHandler(this.button_fr_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_fr);
            this.Controls.Add(this.button_chg);
            this.Controls.Add(this.btn_snf);
            this.Controls.Add(this.button_ch);
            this.Controls.Add(this.text_out);
            this.Controls.Add(this.button_listele);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button_listele;
        private System.Windows.Forms.TextBox text_out;
        private System.Windows.Forms.Button button_ch;
        private System.Windows.Forms.Button btn_snf;
        private System.Windows.Forms.Button button_chg;
        private System.Windows.Forms.Button button_fr;
    }
}

