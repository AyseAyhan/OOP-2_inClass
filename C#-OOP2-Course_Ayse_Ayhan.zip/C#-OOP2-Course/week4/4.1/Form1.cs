﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4._1
{
    //framework neden sadece windows makinelerde çalışır?
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_mesaj_Click(object sender, EventArgs e)
        {
            string mesaj = "Bu benim mesajım: Bu form kapatılsın mı?";
            string baslik = "Bu da mesajın basliği/ Form kapatma";
            MessageBox.Show(mesaj,baslik,MessageBoxButtons.YesNoCancel,MessageBoxIcon.Error); //mesaj, mesaj butonları, mesaj ikonu
            //bu ayarlar işletim sisteminden gelir, örn dil, tarih belirteci sırası/ yapısı vs, bölgesel ayarlar, frameworkün windows makinede çalışma sebebi
            //parametre sayısı veya tipi farklı, adı aynı fonksiyonlar function overloading
            MessageBox.Show(mesaj, baslik, MessageBoxButtons.YesNoCancel, MessageBoxIcon.Information);

            MessageBoxButtons btn = MessageBoxButtons.YesNo; //iki taraf aynı tipte olmalı
            MessageBox.Show(mesaj, baslik, btn, MessageBoxIcon.Error);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //DialogResult dialog=MessageBox.Show("Form ardalan rengi değişsin mi?", "Form Rengi: ", MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);
            DialogResult dialog = MessageBox.Show("Form ardalan rengi değişsin mi?", "Form Rengi: ", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            //seçilen butonu default yapar, daha belirgin görünür
            if (dialog==DialogResult.Yes)
            {
                //formdaki renk değişimi için form yerine this kullanılır
                this.BackColor = Color.Aqua;
                text1.Text = "Evet'e basıldı.";

            }
            else if(dialog==DialogResult.No)
            {
                text1.Text = "Hayır'a basıldı.";
                this.BackColor = SystemColors.Window;
            }
            else
            {
                text1.Text = "Cancel'a basıldı.";
                this.BackColor = SystemColors.Window;
            }
        }

        private void button_font_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog();
            fontDialog.ShowColor= true;
            if(fontDialog.ShowDialog() !=DialogResult.Cancel)
            {
                string myFontName = "";
                float myFontSize = 0;

                myFontName=fontDialog.Font.Name;
                myFontSize = fontDialog.Font.Size;
                MessageBox.Show("Seçili font: " + myFontName + " Seçili font büyüklüğü: " + myFontSize);
                button_font.Font= fontDialog.Font;
                button_font.BackColor = fontDialog.Color;  //yani vuton, fontdialog'dan seçilen renk ve font özelliklerini alır
            }
        }
    }
}
