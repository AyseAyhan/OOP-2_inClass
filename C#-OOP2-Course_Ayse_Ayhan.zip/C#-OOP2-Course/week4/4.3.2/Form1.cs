﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4._1._2
{
    //combo box, list box
    //run time veya preruntime da özellik eklenebilir
    //properties--items
    //örnek proje: combobox ile günler seçildiğinde, bir listbox vs.de de o gün yapılacakların görünmesi
    //!!!uygulama yap: classlardan bir array oluştur, öğrencilerin ad-soyadı comboboxta listelensin,
    //seçilince de öğrenci bilgileri bir textte ya da labelda görünsün, farklı öğrenci-bilgi
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBox1.SelectedIndex = 3; //otomatik olarak seçili gelmesi için
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           /* for(int i=0;i<comboBox1.Items.Count;i++)
            {   if (comboBox1.SelectedIndex == 0)
                { listBox1.Items[i] = "BDA"; }
                if(comboBox1.SelectedIndex==1)
                { listBox1.Items[i] += "ML" + "\tOOP"; }
            } */
           label2.Text="Index: "+comboBox1.SelectedIndex.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "Text: "+comboBox1.Text+", Index: "+comboBox1.SelectedIndex; //index üzerinden çalışmak daha mantıklı, aynı isimler denk gelebilir
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text.Length > 0)
            {
                comboBox2.Items.Add(textBox1.Text); //üzerine mouse'ı getirip bakınca Add'in get metoduyla çalıştığı görülüyor//önemli
                textBox1.Text = string.Empty;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
                comboBox2.Items.Remove("venüs");
                comboBox2.Items.Remove(textBox1.Text);
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
            try
            {
                comboBox2.Items.RemoveAt(2); //removeat ilgili indexteki itemi çıkarır  , index boşsa hata verir

            }
            catch(Exception)
            { }
        }
    }
}
