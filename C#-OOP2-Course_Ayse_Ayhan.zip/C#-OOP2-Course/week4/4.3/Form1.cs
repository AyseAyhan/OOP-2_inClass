﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _4._3
{
    public partial class Form1 : Form
    {
        //monthClaendar date time pickerdan farklı olarak bir tarih aralığı seçmeye izin verir
        //properties max selection count ardışık olarak kaç gün seçilebileceğini belirler
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void monthCalendar_DateChanged(object sender, DateRangeEventArgs e)
        {
            labeltarbas.Text = monthCalendar.SelectionStart.ToLongDateString();
            labeltarbit.Text=monthCalendar.SelectionEnd.ToLongDateString();
            //iki zaman arasındaki fark için
            TimeSpan timespan=monthCalendar.SelectionEnd-monthCalendar.SelectionStart;
            label_daycount.Text = timespan.TotalDays.ToString();  //totaldays olmazsa saati de gösterir
        }

        private void button_change_Click(object sender, EventArgs e)
        {
            monthCalendar.MaxSelectionCount = 4;
        }
    }
}
