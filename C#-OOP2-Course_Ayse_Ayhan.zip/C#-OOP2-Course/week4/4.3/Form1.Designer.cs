﻿namespace _4._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.monthCalendar = new System.Windows.Forms.MonthCalendar();
            this.button_change = new System.Windows.Forms.Button();
            this.labeltarbas = new System.Windows.Forms.Label();
            this.labeltarbit = new System.Windows.Forms.Label();
            this.label_daycount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // monthCalendar
            // 
            this.monthCalendar.Location = new System.Drawing.Point(7, 18);
            this.monthCalendar.Name = "monthCalendar";
            this.monthCalendar.TabIndex = 0;
            this.monthCalendar.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar_DateChanged);
            // 
            // button_change
            // 
            this.button_change.Location = new System.Drawing.Point(7, 192);
            this.button_change.Name = "button_change";
            this.button_change.Size = new System.Drawing.Size(129, 60);
            this.button_change.TabIndex = 1;
            this.button_change.Text = "Max Gün Değiştir";
            this.button_change.UseVisualStyleBackColor = true;
            this.button_change.Click += new System.EventHandler(this.button_change_Click);
            // 
            // labeltarbas
            // 
            this.labeltarbas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labeltarbas.Location = new System.Drawing.Point(282, 25);
            this.labeltarbas.Name = "labeltarbas";
            this.labeltarbas.Size = new System.Drawing.Size(145, 40);
            this.labeltarbas.TabIndex = 2;
            this.labeltarbas.Text = "Tarih Başlangıcı:";
            // 
            // labeltarbit
            // 
            this.labeltarbit.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.labeltarbit.Location = new System.Drawing.Point(282, 73);
            this.labeltarbit.Name = "labeltarbit";
            this.labeltarbit.Size = new System.Drawing.Size(145, 40);
            this.labeltarbit.TabIndex = 3;
            this.labeltarbit.Text = "Tarih Bitişi";
            // 
            // label_daycount
            // 
            this.label_daycount.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_daycount.Location = new System.Drawing.Point(282, 121);
            this.label_daycount.Name = "label_daycount";
            this.label_daycount.Size = new System.Drawing.Size(145, 40);
            this.label_daycount.TabIndex = 4;
            this.label_daycount.Text = "Gün Sayısı:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label_daycount);
            this.Controls.Add(this.labeltarbit);
            this.Controls.Add(this.labeltarbas);
            this.Controls.Add(this.button_change);
            this.Controls.Add(this.monthCalendar);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.MonthCalendar monthCalendar;
        private System.Windows.Forms.Button button_change;
        private System.Windows.Forms.Label labeltarbas;
        private System.Windows.Forms.Label labeltarbit;
        private System.Windows.Forms.Label label_daycount;
    }
}

