﻿namespace _2._1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button_name = new Button();
            txt_name = new TextBox();
            button_colour = new Button();
            txt_colour = new TextBox();
            new_line = new Button();
            button_border = new Button();
            button_passw = new Button();
            text_passw = new TextBox();
            label_passw = new Label();
            button_clr = new Button();
            SuspendLayout();
            // 
            // button_name
            // 
            button_name.BackColor = Color.Transparent;
            button_name.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button_name.Image = Properties.Resources._372903_username_name_full_user_round_icon__1_;
            button_name.ImageAlign = ContentAlignment.BottomCenter;
            button_name.Location = new Point(12, 12);
            button_name.Name = "button_name";
            button_name.Size = new Size(129, 75);
            button_name.TabIndex = 1;
            button_name.Text = "Name";
            button_name.TextAlign = ContentAlignment.TopCenter;
            button_name.UseVisualStyleBackColor = false;
            button_name.Click += button_name_Click;
            // 
            // txt_name
            // 
            txt_name.BackColor = Color.Silver;
            txt_name.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_name.Location = new Point(187, 12);
            txt_name.Multiline = true;
            txt_name.Name = "txt_name";
            txt_name.ScrollBars = ScrollBars.Both;
            txt_name.Size = new Size(199, 174);
            txt_name.TabIndex = 0;
            // 
            // button_colour
            // 
            button_colour.BackColor = Color.Transparent;
            button_colour.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button_colour.Image = Properties.Resources._372903_username_name_full_user_round_icon__1_;
            button_colour.ImageAlign = ContentAlignment.BottomCenter;
            button_colour.Location = new Point(12, 111);
            button_colour.Name = "button_colour";
            button_colour.Size = new Size(129, 75);
            button_colour.TabIndex = 2;
            button_colour.Text = "Colour";
            button_colour.TextAlign = ContentAlignment.TopCenter;
            button_colour.UseVisualStyleBackColor = false;
            button_colour.Click += button_colour_Click;
            // 
            // txt_colour
            // 
            txt_colour.Location = new Point(187, 192);
            txt_colour.Multiline = true;
            txt_colour.Name = "txt_colour";
            txt_colour.Size = new Size(118, 23);
            txt_colour.TabIndex = 5;
            txt_colour.TextChanged += txt_colour_TextChanged;
            // 
            // new_line
            // 
            new_line.BackColor = Color.Transparent;
            new_line.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            new_line.Image = Properties.Resources._372903_username_name_full_user_round_icon__1_;
            new_line.ImageAlign = ContentAlignment.BottomCenter;
            new_line.Location = new Point(12, 210);
            new_line.Name = "new_line";
            new_line.Size = new Size(129, 75);
            new_line.TabIndex = 3;
            new_line.Text = "NewLine";
            new_line.TextAlign = ContentAlignment.TopCenter;
            new_line.UseVisualStyleBackColor = false;
            new_line.Click += new_line_Click;
            // 
            // button_border
            // 
            button_border.BackColor = Color.Transparent;
            button_border.Font = new Font("Segoe UI", 9F, FontStyle.Regular, GraphicsUnit.Point);
            button_border.Image = Properties.Resources._372903_username_name_full_user_round_icon__1_;
            button_border.ImageAlign = ContentAlignment.BottomCenter;
            button_border.Location = new Point(12, 309);
            button_border.Name = "button_border";
            button_border.Size = new Size(129, 75);
            button_border.TabIndex = 4;
            button_border.Text = "Border Style";
            button_border.TextAlign = ContentAlignment.TopCenter;
            button_border.UseVisualStyleBackColor = false;
            button_border.Click += button_border_Click;
            // 
            // button_passw
            // 
            button_passw.Location = new Point(187, 230);
            button_passw.Name = "button_passw";
            button_passw.Size = new Size(152, 39);
            button_passw.TabIndex = 6;
            button_passw.Text = "Read Password";
            button_passw.UseVisualStyleBackColor = true;
            button_passw.Click += button_passw_Click;
            // 
            // text_passw
            // 
            text_passw.Location = new Point(521, 239);
            text_passw.MaxLength = 8;
            text_passw.Name = "text_passw";
            text_passw.PasswordChar = '*';
            text_passw.Size = new Size(178, 23);
            text_passw.TabIndex = 7;
            text_passw.TextChanged += text_passw_TextChanged;
            text_passw.Enter += text_passw_Enter;
            text_passw.KeyDown += text_passw_KeyDown;
            text_passw.Leave += text_passw_Leave;
            // 
            // label_passw
            // 
            label_passw.AutoSize = true;
            label_passw.Location = new Point(345, 289);
            label_passw.Name = "label_passw";
            label_passw.Size = new Size(0, 15);
            label_passw.TabIndex = 8;
            // 
            // button_clr
            // 
            button_clr.Location = new Point(345, 230);
            button_clr.Name = "button_clr";
            button_clr.Size = new Size(152, 39);
            button_clr.TabIndex = 9;
            button_clr.Text = "Clear";
            button_clr.UseVisualStyleBackColor = true;
            button_clr.Click += button_clr_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button_clr);
            Controls.Add(label_passw);
            Controls.Add(text_passw);
            Controls.Add(button_passw);
            Controls.Add(button_border);
            Controls.Add(new_line);
            Controls.Add(txt_colour);
            Controls.Add(button_colour);
            Controls.Add(txt_name);
            Controls.Add(button_name);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button_name;
        private TextBox txt_name;
        private Button button_colour;
        private TextBox txt_colour;
        private Button new_line;
        private Button button_border;
        private Button button_passw;
        private TextBox text_passw;
        private Label label_passw;
        private Button button_clr;
    }
}