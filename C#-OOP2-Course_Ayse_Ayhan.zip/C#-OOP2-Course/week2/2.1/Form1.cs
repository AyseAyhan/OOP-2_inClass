namespace _2._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_name_Click(object sender, EventArgs e)
        {
            txt_name.Text = "Enter a name here";   //toolsette hem get hem set �zelli�i var yani textbox'�n text �zelli�i hem okunur hem yaz�l�r
            txt_name.BackColor = Color.Red;
            txt_name.ForeColor = Color.White;
        }

        private void button_colour_Click(object sender, EventArgs e)
        {
            /*txt_colour.Text = "Enter your favourite colour";
           txt_colour.Text = "darkblue";
            txt_colour.BackColor = Color.Aqua;
            txt_colour.ForeColor = Color.RosyBrown; */
            txt_name.BackColor = Color.Aqua;
            txt_name.ForeColor = Color.Black;

        }

        private void txt_colour_TextChanged(object sender, EventArgs e)
        {

        }

        private void new_line_Click(object sender, EventArgs e)
        {
            /*txt_name.Text="1.line "+Environment.NewLine;
            txt_name.Text = "2.line " + Environment.NewLine;
            txt_name.Text = "3.line " + Environment.NewLine; */  //bu �ekilde yap�l�rsa alt alta yazma yapmaz, e�ittir operat�r� texti e�itler yani son e�itlenen g�r�necektir: "3.line"

            txt_name.Text = "1.line " + Environment.NewLine;
            txt_name.Text = txt_name.Text + "2.line " + Environment.NewLine;
            txt_name.Text += "3.line " + Environment.NewLine;
        }

        private void button_border_Click(object sender, EventArgs e)
        {
            if (txt_name.BorderStyle == BorderStyle.Fixed3D)
            {
                txt_name.BorderStyle = BorderStyle.None;
            }
            else
            {
                txt_name.BorderStyle = BorderStyle.Fixed3D;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_passw_Click(object sender, EventArgs e)
        {
            label_passw.Text = text_passw.Text;  //butona t�kland���nda labelda yazacak olan = texte i�lenen �ifre
            //properties maxi length= 8 ayarlad�m
            //readonly true olursa texte yazma yap�lamaz, �rn �nceki a�amay� doldurmad�ysa yenisine ge�memesi i�in, if statement koyulabilir if(...) txt.readonly==true
        }

        private void text_passw_TextChanged(object sender, EventArgs e)
        {
            // label_passw.Text = text_passw.Text;  //texte girilen �ifre de�i�tik�e label de�i�ir
        }

        private void button_clr_Click(object sender, EventArgs e)
        {
            text_passw.Text = " ";   //ikisi de silme i�lemi yapar
            text_passw.Clear();

            //entera bas�ld���nda silmek ya da yazd�rmak i�in? --key eventleri kullan�l�r   keydown yerine di�er se�enekler de uygun olur
        }

        private void text_passw_KeyDown(object sender, KeyEventArgs key_value)
        {
            if (key_value.KeyCode == (Keys.Enter))
            {
                label_passw.Text = text_passw.Text;
            }
        }

        private void text_passw_Enter(object sender, EventArgs e)
        {
            //focus i�in, mouse �zerindeyken renkli olmas� i�in
            text_passw.BackColor = Color.Yellow;
        }

        private void text_passw_Leave(object sender, EventArgs e)
        {
            //mouse, yaz�dan ��k�nca
            text_passw.BackColor= Color.White;
        }
    }
}