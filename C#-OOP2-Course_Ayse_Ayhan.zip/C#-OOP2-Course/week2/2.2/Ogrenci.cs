﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2._2
{
    internal class Ogrenci
    {
        private String ogr_name;
        public void SetName(String name)
        {
            ogr_name = name;
        }
        public String GetName()
        {
            return ogr_name;
        }
    }
}
