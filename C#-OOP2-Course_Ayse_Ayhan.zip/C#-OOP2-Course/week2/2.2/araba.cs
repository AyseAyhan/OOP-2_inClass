﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2._2
{
    internal class Araba
    {
        private int car_year;
        private string car_brand;
        private int car_menzil;
        // private string car_name;
        //Constructor, nesneyi oluşturmada kullanılır

        public Araba(int caryear, string carbrand, int carmenzil)
        {
            car_year = caryear;
            car_brand = carbrand;
            car_menzil = carmenzil;

        }

        public void SetYear(int year)
        {   //prop+tab(x2)
            car_year = year;

          }
        public int GetYear()
        {
            return car_year;
        }
        public void SetBrand(string brand)
        {
            car_brand = brand;
        
        }
        public string GetBrand()
        {
            return car_brand;
        }
        public void SetMenzil(int menzil)
        {
            if (menzil > 0)
            {
                car_menzil = menzil;
            }
            else
                car_menzil = 0;
        }
        public int GetMenzil()
        {
            return car_menzil;
        }
    }
}
