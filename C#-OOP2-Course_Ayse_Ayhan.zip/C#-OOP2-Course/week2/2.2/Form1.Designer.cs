﻿namespace _2._2
{
    //classlar
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button_read = new Button();
            text_name = new TextBox();
            button_car = new Button();
            text_car = new TextBox();
            text2_car = new TextBox();
            text3_car = new TextBox();
            label_sum = new Label();
            text2_sum = new TextBox();
            text1_sum = new TextBox();
            button_sum = new Button();
            label_ssum = new Label();
            SuspendLayout();
            // 
            // button_read
            // 
            button_read.Location = new Point(12, 10);
            button_read.Name = "button_read";
            button_read.Size = new Size(115, 53);
            button_read.TabIndex = 0;
            button_read.Text = "Read Student";
            button_read.UseVisualStyleBackColor = true;
            button_read.Click += button_read_Click;
            // 
            // text_name
            // 
            text_name.Font = new Font("Segoe UI", 9F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            text_name.Location = new Point(146, 26);
            text_name.Name = "text_name";
            text_name.Size = new Size(179, 23);
            text_name.TabIndex = 1;
            text_name.Text = "Enter a name here. ";
            text_name.Click += text_name_Click;
            // 
            // button_car
            // 
            button_car.Location = new Point(12, 97);
            button_car.Name = "button_car";
            button_car.Size = new Size(115, 53);
            button_car.TabIndex = 2;
            button_car.Text = "Read Car";
            button_car.UseVisualStyleBackColor = true;
            button_car.Click += button_car_Click;
            // 
            // text_car
            // 
            text_car.Font = new Font("Segoe UI", 9F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            text_car.Location = new Point(144, 113);
            text_car.Multiline = true;
            text_car.Name = "text_car";
            text_car.Size = new Size(188, 23);
            text_car.TabIndex = 3;
            text_car.Text = "Car Properties";
            text_car.Click += text_car_Click;
            // 
            // text2_car
            // 
            text2_car.Font = new Font("Segoe UI", 9F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            text2_car.Location = new Point(144, 141);
            text2_car.Name = "text2_car";
            text2_car.Size = new Size(188, 23);
            text2_car.TabIndex = 4;
            text2_car.Text = "Car properties";
            text2_car.Click += text2_car_Click;
            // 
            // text3_car
            // 
            text3_car.Font = new Font("Segoe UI", 9F, FontStyle.Italic | FontStyle.Underline, GraphicsUnit.Point);
            text3_car.Location = new Point(144, 170);
            text3_car.Name = "text3_car";
            text3_car.Size = new Size(188, 23);
            text3_car.TabIndex = 5;
            text3_car.Text = "Car properties";
            text3_car.Click += text3_car_Click;
            text3_car.TextChanged += textBox1_TextChanged;
            // 
            // label_sum
            // 
            label_sum.Anchor = AnchorStyles.None;
            label_sum.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label_sum.Location = new Point(12, 238);
            label_sum.Name = "label_sum";
            label_sum.Size = new Size(100, 23);
            label_sum.TabIndex = 6;
            label_sum.Text = "SUM";
            label_sum.TextAlign = ContentAlignment.MiddleCenter;
            label_sum.Click += label_sum_Click;
            // 
            // text2_sum
            // 
            text2_sum.Location = new Point(250, 238);
            text2_sum.Name = "text2_sum";
            text2_sum.Size = new Size(100, 23);
            text2_sum.TabIndex = 7;
            // 
            // text1_sum
            // 
            text1_sum.Location = new Point(144, 238);
            text1_sum.Name = "text1_sum";
            text1_sum.Size = new Size(100, 23);
            text1_sum.TabIndex = 8;
            // 
            // button_sum
            // 
            button_sum.Location = new Point(12, 278);
            button_sum.Name = "button_sum";
            button_sum.Size = new Size(114, 38);
            button_sum.TabIndex = 9;
            button_sum.Text = "Sum String";
            button_sum.UseVisualStyleBackColor = true;
            button_sum.Click += button_sum_Click;
            // 
            // label_ssum
            // 
            label_ssum.Location = new Point(144, 290);
            label_ssum.Name = "label_ssum";
            label_ssum.Size = new Size(206, 26);
            label_ssum.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label_ssum);
            Controls.Add(button_sum);
            Controls.Add(text1_sum);
            Controls.Add(text2_sum);
            Controls.Add(label_sum);
            Controls.Add(text3_car);
            Controls.Add(text2_car);
            Controls.Add(text_car);
            Controls.Add(button_car);
            Controls.Add(text_name);
            Controls.Add(button_read);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button_read;
        private TextBox text_name;
        private Button button_car;
        private TextBox text_car;
        private TextBox text2_car;
        private TextBox text3_car;
        private Label label_sum;
        private TextBox text2_sum;
        private TextBox text1_sum;
        private Button button_sum;
        private Label label_ssum;
    }
}