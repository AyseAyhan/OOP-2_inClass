namespace _2._2
{
    public partial class Form1 : Form
    {

        Ogrenci ogrenci;
        Araba araba;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e) //bu k�sma class metotlar�na g�nderilecek olan veriler
        {
            ogrenci = new Ogrenci();
            ogrenci.SetName("Aysh");
            ogrenci.GetName();

            araba = new Araba(1898, "Ford", 60);
            // araba.SetYear(1898);
            // araba.SetBrand("Ford");
            // araba.SetMenzil(60);
        }

        private int Topla(int a, int b)
        {
            int sum = a + b;
            return sum;
        }
        private string Sum(int a, int b)
        {
            int sum = a + b;
            return "Number 1: " + a + " + Number 2: " + b + " = " + sum;
        }

        private void button_read_Click(object sender, EventArgs e)
        {
            text_name.Text = ogrenci.GetName();
        }

        private void text_name_Click(object sender, EventArgs e)
        {
            // text_name.Text = "";
            text_name.Clear();
        }

        private void button_car_Click(object sender, EventArgs e)
        {
            text_car.Text = "The car was invented in " + araba.GetYear().ToString();
            text2_car.Text = " By the " + araba.GetBrand() + " Company.";
            text3_car.Text = " With " + araba.GetMenzil().ToString() + " km";
        }

        private void text_car_Click(object sender, EventArgs e)
        {
            text_car.Clear();
        }

        private void text2_car_Click(object sender, EventArgs e)
        {
            text2_car.Clear();
        }
        
        private void text3_car_Click(object sender, EventArgs e)
        {
            text3_car.Clear();
        }

        private void label_sum_Click(object sender, EventArgs e)  //sum butonuna t�kland���nda bir labela ��kt�y� yazd�rmak daha uygun
        {
            int num1 = int.Parse(text1_sum.Text);   //stringi inte �evirme
            int num2 = Convert.ToInt32(text2_sum.Text);
            label_sum.Text = Topla(num1, num2).ToString();  //stringe �evrilmek zorunda
        }

        private void button_sum_Click(object sender, EventArgs e)
        {
            if (text1_sum.Text != "" && text2_sum.Text != "")  //bo�luk de�ilse toplama i�lemi yap, try-catch e de koyulabilir
            {
                int n1 = Convert.ToInt32(text1_sum.Text);
                int n2 = int.Parse(text2_sum.Text);  //iki �ekilde de �evrilebilir
                label_ssum.Text = Sum(n1, n2).ToString();
            }           
        }
    }
}