﻿//IDENTİFY SP. tekliğini garanti eder
//CRUD create read update
//connection string: Server=myServerAddress;Database=myDataBase;Trusted_Connection=True;
//kütüphane için tools-nuget package manager
//SQL   
//SELECT FROM TABLO WHERE...
//sql de P% ilk harfi p, sonrası önemsiz olan kelimeler için
//%P, herhangi bir şeyler başlasın p ile bitsin, __r gibi-ilk iki karakteri rastgele


using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;

namespace _10
{
    public partial class Form1 : Form
    {
        SqlConnection sqlConn;
        SqlCommand cmd;

        public Form1()
        {
            InitializeComponent();
            sqlConn = new SqlConnection("Server=DESKTOP-GND5VRN\\SQLEXPRESS;Database=AdventureWorksLT2019;Trusted_Connection=True;");
            cmd = new SqlCommand();
            cmd.Connection = sqlConn;
        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn.Open();
                if (sqlConn.State == ConnectionState.Open)
                {
                    txt_cncstring.Text = "Successfully Connected";
                    txt_cncstring.BackColor = Color.DarkOliveGreen;
                }
                else
                {
                    txt_cncstring.Text = "Connection failed";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to the database: " + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                sqlConn.Open();
                if (sqlConn.State == ConnectionState.Open)
                {
                    txt_cncstring.Text = "Successfully Disconnected";
                    txt_cncstring.BackColor = Color.Gray;
                }
                else
                {
                    txt_cncstring.Text = "Disconnection failed";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error disconnecting from the database: " + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "INSERT INTO Employees (Username, Usersurname, Age, Department) VALUES (@Username, @Usersurname, @Age, @Department)";
                using (SqlCommand insertCmd = new SqlCommand(query, sqlConn))
                {
                    insertCmd.Parameters.AddWithValue("@Username", txt_name.Text);
                    insertCmd.Parameters.AddWithValue("@Usersurname", txt_sname.Text);
                    insertCmd.Parameters.AddWithValue("@Age", int.Parse(txt_age.Text));
                    insertCmd.Parameters.AddWithValue("@Department", txt_dep.Text);

                    sqlConn.Open();
                    insertCmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding employee: " + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void btn_list_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "SELECT * FROM Employees";
                using (SqlCommand selectCmd = new SqlCommand(query, sqlConn))
                {
                    sqlConn.Open();
                    DataTable dt = new DataTable();
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(selectCmd);
                    dataAdapter.Fill(dt);
                    dataGrid.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error retrieving employee list: " + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "DELETE FROM Employees WHERE ID = @ID";
                using (SqlCommand deleteCmd = new SqlCommand(query, sqlConn))
                {
                    deleteCmd.Parameters.AddWithValue("@ID", int.Parse(lb_id.Text));

                    sqlConn.Open();
                    deleteCmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting employee: " + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void btn_update_Click(object sender, EventArgs e)
        {
            try
            {
                string query = "UPDATE Employees SET Username = @Username, Usersurname = @Usersurname, Age = @Age, Department = @Department WHERE ID = @ID";
                using (SqlCommand updateCmd = new SqlCommand(query, sqlConn))
                {
                    updateCmd.Parameters.AddWithValue("@Username", txt_name.Text);
                    updateCmd.Parameters.AddWithValue("@Usersurname", txt_sname.Text);
                    updateCmd.Parameters.AddWithValue("@Age", int.Parse(txt_age.Text));
                    updateCmd.Parameters.AddWithValue("@Department", txt_dep.Text);
                    updateCmd.Parameters.AddWithValue("@ID", int.Parse(lb_id.Text));

                    sqlConn.Open();
                    updateCmd.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating employee: " + ex.Message);
            }
            finally
            {
                sqlConn.Close();
            }
        }

        private void dataGrid_SelectionChanged(object sender, EventArgs e)
        {
            try
            {
                if (dataGrid.SelectedRows.Count > 0)
                {
                    int selectedIndex = dataGrid.SelectedRows[0].Index;
                    if (selectedIndex >= 0 && selectedIndex < dataGrid.Rows.Count)
                    {
                        DataGridViewRow selectedRow = dataGrid.Rows[selectedIndex];
                        lb_id.Text = selectedRow.Cells["ID"].Value.ToString();
                        txt_name.Text = selectedRow.Cells["Username"].Value.ToString();
                        txt_sname.Text = selectedRow.Cells["Usersurname"].Value.ToString();
                        txt_age.Text = selectedRow.Cells["Age"].Value.ToString();
                        txt_dep.Text = selectedRow.Cells["Department"].Value.ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error selecting employee: " + ex.Message);
            }
        }
    }
}


