﻿namespace _10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_connect = new System.Windows.Forms.Button();
            this.txt_cncstring = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_add = new System.Windows.Forms.Button();
            this.lb_name = new System.Windows.Forms.Label();
            this.lb_sname = new System.Windows.Forms.Label();
            this.lb_age = new System.Windows.Forms.Label();
            this.lb_dep = new System.Windows.Forms.Label();
            this.lb_id = new System.Windows.Forms.Label();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.txt_sname = new System.Windows.Forms.TextBox();
            this.txt_age = new System.Windows.Forms.TextBox();
            this.txt_dep = new System.Windows.Forms.TextBox();
            this.dataGrid = new System.Windows.Forms.DataGridView();
            this.btn_list = new System.Windows.Forms.Button();
            this.btn_update = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_connect
            // 
            this.btn_connect.Location = new System.Drawing.Point(12, 30);
            this.btn_connect.Name = "btn_connect";
            this.btn_connect.Size = new System.Drawing.Size(138, 25);
            this.btn_connect.TabIndex = 0;
            this.btn_connect.Text = "CONNECT SQL ";
            this.btn_connect.UseVisualStyleBackColor = true;
            this.btn_connect.Click += new System.EventHandler(this.btn_connect_Click);
            // 
            // txt_cncstring
            // 
            this.txt_cncstring.Location = new System.Drawing.Point(166, 45);
            this.txt_cncstring.Multiline = true;
            this.txt_cncstring.Name = "txt_cncstring";
            this.txt_cncstring.Size = new System.Drawing.Size(174, 25);
            this.txt_cncstring.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 61);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 27);
            this.button1.TabIndex = 2;
            this.button1.Text = "DISCONNECT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_add
            // 
            this.btn_add.Location = new System.Drawing.Point(40, 94);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 3;
            this.btn_add.Text = "Ekle";
            this.btn_add.UseVisualStyleBackColor = true;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // lb_name
            // 
            this.lb_name.Location = new System.Drawing.Point(12, 233);
            this.lb_name.Name = "lb_name";
            this.lb_name.Size = new System.Drawing.Size(100, 20);
            this.lb_name.TabIndex = 4;
            this.lb_name.Text = "Username";
            // 
            // lb_sname
            // 
            this.lb_sname.Location = new System.Drawing.Point(12, 274);
            this.lb_sname.Name = "lb_sname";
            this.lb_sname.Size = new System.Drawing.Size(100, 20);
            this.lb_sname.TabIndex = 5;
            this.lb_sname.Text = "Surname";
            // 
            // lb_age
            // 
            this.lb_age.Location = new System.Drawing.Point(12, 316);
            this.lb_age.Name = "lb_age";
            this.lb_age.Size = new System.Drawing.Size(100, 20);
            this.lb_age.TabIndex = 6;
            this.lb_age.Text = "Age";
            // 
            // lb_dep
            // 
            this.lb_dep.Location = new System.Drawing.Point(9, 356);
            this.lb_dep.Name = "lb_dep";
            this.lb_dep.Size = new System.Drawing.Size(100, 20);
            this.lb_dep.TabIndex = 7;
            this.lb_dep.Text = "Department";
            // 
            // lb_id
            // 
            this.lb_id.Location = new System.Drawing.Point(112, 192);
            this.lb_id.Name = "lb_id";
            this.lb_id.Size = new System.Drawing.Size(100, 22);
            this.lb_id.TabIndex = 8;
            this.lb_id.Text = "ID";
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(115, 233);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 9;
            // 
            // txt_sname
            // 
            this.txt_sname.Location = new System.Drawing.Point(115, 273);
            this.txt_sname.Name = "txt_sname";
            this.txt_sname.Size = new System.Drawing.Size(100, 20);
            this.txt_sname.TabIndex = 10;
            // 
            // txt_age
            // 
            this.txt_age.Location = new System.Drawing.Point(115, 313);
            this.txt_age.Name = "txt_age";
            this.txt_age.Size = new System.Drawing.Size(100, 20);
            this.txt_age.TabIndex = 11;
            // 
            // txt_dep
            // 
            this.txt_dep.Location = new System.Drawing.Point(115, 353);
            this.txt_dep.Name = "txt_dep";
            this.txt_dep.Size = new System.Drawing.Size(100, 20);
            this.txt_dep.TabIndex = 12;
            // 
            // dataGrid
            // 
            this.dataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGrid.Location = new System.Drawing.Point(238, 226);
            this.dataGrid.Name = "dataGrid";
            this.dataGrid.Size = new System.Drawing.Size(378, 212);
            this.dataGrid.TabIndex = 13;
            this.dataGrid.SelectionChanged += new System.EventHandler(this.dataGrid_SelectionChanged);
            // 
            // btn_list
            // 
            this.btn_list.Location = new System.Drawing.Point(143, 94);
            this.btn_list.Name = "btn_list";
            this.btn_list.Size = new System.Drawing.Size(75, 23);
            this.btn_list.TabIndex = 14;
            this.btn_list.Text = "Listele";
            this.btn_list.UseVisualStyleBackColor = true;
            this.btn_list.Click += new System.EventHandler(this.btn_list_Click);
            // 
            // btn_update
            // 
            this.btn_update.Location = new System.Drawing.Point(246, 94);
            this.btn_update.Name = "btn_update";
            this.btn_update.Size = new System.Drawing.Size(75, 23);
            this.btn_update.TabIndex = 15;
            this.btn_update.Text = "Update";
            this.btn_update.UseVisualStyleBackColor = true;
            this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(349, 94);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(75, 23);
            this.btn_delete.TabIndex = 16;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(623, 450);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.btn_update);
            this.Controls.Add(this.btn_list);
            this.Controls.Add(this.dataGrid);
            this.Controls.Add(this.txt_dep);
            this.Controls.Add(this.txt_age);
            this.Controls.Add(this.txt_sname);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.lb_id);
            this.Controls.Add(this.lb_dep);
            this.Controls.Add(this.lb_age);
            this.Controls.Add(this.lb_sname);
            this.Controls.Add(this.lb_name);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.txt_cncstring);
            this.Controls.Add(this.btn_connect);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.dataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_connect;
        private System.Windows.Forms.TextBox txt_cncstring;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Label lb_name;
        private System.Windows.Forms.Label lb_sname;
        private System.Windows.Forms.Label lb_age;
        private System.Windows.Forms.Label lb_dep;
        private System.Windows.Forms.Label lb_id;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.TextBox txt_sname;
        private System.Windows.Forms.TextBox txt_age;
        private System.Windows.Forms.TextBox txt_dep;
        private System.Windows.Forms.DataGridView dataGrid;
        private System.Windows.Forms.Button btn_list;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Button btn_delete;
    }
}

