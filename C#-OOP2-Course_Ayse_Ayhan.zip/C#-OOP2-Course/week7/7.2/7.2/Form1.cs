﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _7._2
{
    //IsMdiContainer=true
    //windowstate propertie
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void exitToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void formTip1AçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            child1 frm_child1 = new child1();
            frm_child1.MdiParent = this;
            frm_child1.Show();

        }

        private void formTip2AçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            child2 frm_child2 = new child2();
            frm_child2.MdiParent = this;
            frm_child2.Show();
        }

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(System.Windows.Forms.MdiLayout.Cascade);  //üst üste açılması için
        }

        private void tileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(System.Windows.Forms.MdiLayout.TileVertical);   //düzenli açılması için
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Text = DateTime.Now.ToLongDateString();
        }
    }
}
