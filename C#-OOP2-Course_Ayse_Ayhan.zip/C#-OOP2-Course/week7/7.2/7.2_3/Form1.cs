﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _7._2_3
{
    public partial class Form1 : Form
    {
        int x=10, y=20, index=1;
       // int z = 40, w = 20, index2 = 1;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            foreach(Control item in this.Controls)
            {
                if(item is TextBox)
                {
                    ((TextBox)item).Text = " ";
                }

                //ya da
                if ((item is TextBox) && (((TextBox)item).Name=="txt1"))
                {
                    // ((TextBox)item).Text = " ";
                    ((TextBox)item).Text = "Buldum seni";
                }
            }
        }

        void btn_Click(object sender, EventArgs e)//ben ekledim, yeni butonlar için
        {
            Button tmp = (Button)sender;
            if (tmp.Name == "Button1")
            {
                MessageBox.Show("Tıklandı " + tmp.Name);
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {

            Button btn = new Button();
            btn.Location = new Point(x, index* y);
            btn.Name = "Button" + index;
            btn.Text = "Button" + index;
            //ÖNEMLİ, SEN EKLEMELİSİN
            btn.Click += new EventHandler(btn_Click);
            this.Controls.Add(btn);
            index++;
        }

        private void AddTextBox()   //forma sonradan textbox vs. eklemek, dinamik olarak-çalışma sırasında eklemek, veritabanından okuma yaparken sonradan eklemek gerekebilir//örn anketlerde
        {

            TextBox textBox = new TextBox();
            textBox.Location = new Point(x, index*y);
            //Point pnt=new Point(x,y);
            //textBox.Location=pnt;
            textBox.Name= "txt1"+index;
            textBox.Text = "txt1" + index;
            index ++;
            this.Controls.Add(textBox); //textbox forma eklenmek zorunda
        }
        private void btn1_Click(object sender, EventArgs e)
        {
            AddTextBox();
        }
    }

   



}
