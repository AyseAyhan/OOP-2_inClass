﻿namespace _7._2_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt1 = new System.Windows.Forms.TextBox();
            this.btn_method1 = new System.Windows.Forms.Button();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.btn_method2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(23, 12);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(189, 20);
            this.txt1.TabIndex = 0;
            // 
            // btn_method1
            // 
            this.btn_method1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_method1.Location = new System.Drawing.Point(35, 100);
            this.btn_method1.Name = "btn_method1";
            this.btn_method1.Size = new System.Drawing.Size(151, 23);
            this.btn_method1.TabIndex = 2;
            this.btn_method1.Text = "Open Form 2 (1)";
            this.btn_method1.UseVisualStyleBackColor = true;
            this.btn_method1.Click += new System.EventHandler(this.btn_method1_Click);
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(23, 51);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(189, 20);
            this.txt2.TabIndex = 3;
            // 
            // btn_method2
            // 
            this.btn_method2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_method2.Location = new System.Drawing.Point(35, 142);
            this.btn_method2.Name = "btn_method2";
            this.btn_method2.Size = new System.Drawing.Size(151, 23);
            this.btn_method2.TabIndex = 4;
            this.btn_method2.Text = "Open Form 2 (2)";
            this.btn_method2.UseVisualStyleBackColor = true;
            this.btn_method2.Click += new System.EventHandler(this.btn_method2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_method2);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.btn_method1);
            this.Controls.Add(this.txt1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Button btn_method1;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.Button btn_method2;
    }
}

