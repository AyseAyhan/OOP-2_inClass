﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _7._2_2
{
    //static değişkenler hafızada kaldığı için az kullanmak daha iyi
    public partial class Form2 : Form
    {
        private string par1, par2;
        public Form2()  //form 2 contructor
        {
            InitializeComponent();
        }

        //overloading
        public Form2(string Par1, string Par2)
        {
            InitializeComponent();
            par1= Par1;
            par2= Par2;

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            try
            {
                lb_par1.Text = par1;
                lb_par2.Text = par2;
            }
            catch(Exception) { }
            try
            {
                lb_par1.Text = Form1.param1;
                lb_par2.Text = Form1.param2;
            }
            catch(Exception) { }
        }
    }
}
