﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _7._3
{
    //STACK-LIFO;   QUEUE-FIFO;
    public partial class Form1 : Form
    {
        System.Collections.Queue kuyruk = new System.Collections.Queue();
        System.Collections.Stack stack = new System.Collections.Generic.Stack();

        int num = 0;
       
        public Form1()
        {
            InitializeComponent();
        }

        private void KuyrukListele()
        {
          listbox1.Items.Clear();
            foreach(int item in kuyruk)
            {
                listbox1.Items.Add(item);
            }
        }

        private void StackListele()
        {
            listbox1.Items.Clear();
            foreach(int item in stack)
            { listbox1.Items.Add(item);}
        }


        private void btn_enq_Click(object sender, EventArgs e)
        {
            num++;
            kuyruk.Enqueue(num);
            KuyrukListele();
        }

        private void btn_deq_Click(object sender, EventArgs e)
        {
            if (listbox1.Items.Count > 0)
            { 
            lb1.Text = ((int)kuyruk.Dequeue()).ToString();
            }
            KuyrukListele();
        }

        private void btn_pop_Click(object sender, EventArgs e)
        {
            if (listbox1.Items.Count > 0)
            { 
            lb1.Text = ((int)stack.Pop()).ToString();
             }
            StackListele();
        }

        private void btn_push_Click(object sender, EventArgs e)
        {
            num++;
            stack.Push(num);
            StackListele();

        }
    }
}
