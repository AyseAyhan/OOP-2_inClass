﻿namespace _7._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_enq = new System.Windows.Forms.Button();
            this.btn_deq = new System.Windows.Forms.Button();
            this.btn_pop = new System.Windows.Forms.Button();
            this.btn_push = new System.Windows.Forms.Button();
            this.listbox1 = new System.Windows.Forms.ListBox();
            this.lb1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_enq
            // 
            this.btn_enq.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_enq.Location = new System.Drawing.Point(29, 29);
            this.btn_enq.Name = "btn_enq";
            this.btn_enq.Size = new System.Drawing.Size(85, 53);
            this.btn_enq.TabIndex = 0;
            this.btn_enq.Text = "Enqueue";
            this.btn_enq.UseVisualStyleBackColor = true;
            this.btn_enq.Click += new System.EventHandler(this.btn_enq_Click);
            // 
            // btn_deq
            // 
            this.btn_deq.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_deq.Location = new System.Drawing.Point(29, 88);
            this.btn_deq.Name = "btn_deq";
            this.btn_deq.Size = new System.Drawing.Size(85, 53);
            this.btn_deq.TabIndex = 1;
            this.btn_deq.Text = "Dequeue";
            this.btn_deq.UseVisualStyleBackColor = true;
            this.btn_deq.Click += new System.EventHandler(this.btn_deq_Click);
            // 
            // btn_pop
            // 
            this.btn_pop.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_pop.Location = new System.Drawing.Point(517, 31);
            this.btn_pop.Name = "btn_pop";
            this.btn_pop.Size = new System.Drawing.Size(89, 47);
            this.btn_pop.TabIndex = 2;
            this.btn_pop.Text = "Pop";
            this.btn_pop.UseVisualStyleBackColor = true;
            this.btn_pop.Click += new System.EventHandler(this.btn_pop_Click);
            // 
            // btn_push
            // 
            this.btn_push.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_push.Location = new System.Drawing.Point(517, 84);
            this.btn_push.Name = "btn_push";
            this.btn_push.Size = new System.Drawing.Size(89, 47);
            this.btn_push.TabIndex = 3;
            this.btn_push.Text = "Push";
            this.btn_push.UseVisualStyleBackColor = true;
            this.btn_push.Click += new System.EventHandler(this.btn_push_Click);
            // 
            // listbox1
            // 
            this.listbox1.FormattingEnabled = true;
            this.listbox1.Location = new System.Drawing.Point(140, 25);
            this.listbox1.Name = "listbox1";
            this.listbox1.Size = new System.Drawing.Size(352, 303);
            this.listbox1.TabIndex = 4;
            // 
            // lb1
            // 
            this.lb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb1.Location = new System.Drawing.Point(270, 341);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(100, 23);
            this.lb1.TabIndex = 5;
            this.lb1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lb1);
            this.Controls.Add(this.listbox1);
            this.Controls.Add(this.btn_push);
            this.Controls.Add(this.btn_pop);
            this.Controls.Add(this.btn_deq);
            this.Controls.Add(this.btn_enq);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_enq;
        private System.Windows.Forms.Button btn_deq;
        private System.Windows.Forms.Button btn_pop;
        private System.Windows.Forms.Button btn_push;
        private System.Windows.Forms.ListBox listbox1;
        private System.Windows.Forms.Label lb1;
    }
}

