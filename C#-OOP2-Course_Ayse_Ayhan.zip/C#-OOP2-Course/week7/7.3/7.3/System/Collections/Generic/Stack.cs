﻿namespace System.Collections.Generic
{
    internal class Stack : Collections.Stack
    {
    }
}