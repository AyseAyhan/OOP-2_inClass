﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _7._1
{
    //timer, stack-queue...
    //7.1 Timer,Trackbar, statustrip
    //timer ekleyince tıpkı contextmenu gibi aşağıda görünüyor
    //enabled true ise çalışır, interval ayarlanabilir
    public partial class Form1 : Form
    {
        int num = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            timer1.Interval = track1.Value;  //trackbarın değeri .value ile alınır
            lbtrack.Text = track1.Value.ToString();
            //pr1.Value = track1.Value;
            // lbprog.Text=pr1.Value.ToString();
            status_user.Text = "Ayşe Ayhan Giriş: " + DateTime.Now.ToLongDateString();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            // txt1.Text = DateTime.Now.ToLongTimeString();
            txt1.Text += DateTime.Now.ToLongTimeString()+Environment.NewLine;
            lb1.Text = DateTime.Now.ToLongTimeString();
            status_saat.Text= DateTime.Now.ToLongTimeString();
            num++;
            if (num <= 100)
            {
                pr1.Value = num;
                lbprog.Text = pr1.Value.ToString();
            }

            if (num <= 100)
            {
                status_prog.Value = num;
            }
        }

        private void track1_Scroll(object sender, EventArgs e)
        {
            timer1.Interval = track1.Value;  //trackbarın değeri .value ile alınır
            lbtrack.Text=track1.Value.ToString();
        }

        private void menu1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Menu1 çalıştı");
        }
    }
}
