﻿namespace _7._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.txt1 = new System.Windows.Forms.TextBox();
            this.lb1 = new System.Windows.Forms.Label();
            this.track1 = new System.Windows.Forms.TrackBar();
            this.lbtrack = new System.Windows.Forms.Label();
            this.pr1 = new System.Windows.Forms.ProgressBar();
            this.lbprog = new System.Windows.Forms.Label();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.status_user = new System.Windows.Forms.ToolStripStatusLabel();
            this.status_prog = new System.Windows.Forms.ToolStripProgressBar();
            this.status_saat = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripDropDownButton1 = new System.Windows.Forms.ToolStripDropDownButton();
            this.menu1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.track1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(27, 36);
            this.txt1.Multiline = true;
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(314, 390);
            this.txt1.TabIndex = 0;
            // 
            // lb1
            // 
            this.lb1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lb1.Location = new System.Drawing.Point(370, 39);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(100, 23);
            this.lb1.TabIndex = 1;
            // 
            // track1
            // 
            this.track1.Location = new System.Drawing.Point(373, 90);
            this.track1.Maximum = 10000;
            this.track1.Minimum = 100;
            this.track1.Name = "track1";
            this.track1.Size = new System.Drawing.Size(311, 45);
            this.track1.TabIndex = 2;
            this.track1.TickFrequency = 100;
            this.track1.Value = 100;
            this.track1.Scroll += new System.EventHandler(this.track1_Scroll);
            // 
            // lbtrack
            // 
            this.lbtrack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbtrack.Location = new System.Drawing.Point(480, 126);
            this.lbtrack.Name = "lbtrack";
            this.lbtrack.Size = new System.Drawing.Size(100, 23);
            this.lbtrack.TabIndex = 3;
            this.lbtrack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pr1
            // 
            this.pr1.Location = new System.Drawing.Point(373, 191);
            this.pr1.Name = "pr1";
            this.pr1.Size = new System.Drawing.Size(311, 23);
            this.pr1.TabIndex = 4;
            // 
            // lbprog
            // 
            this.lbprog.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbprog.Location = new System.Drawing.Point(507, 245);
            this.lbprog.Name = "lbprog";
            this.lbprog.Size = new System.Drawing.Size(100, 23);
            this.lbprog.TabIndex = 5;
            this.lbprog.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.status_user,
            this.status_prog,
            this.status_saat,
            this.toolStripDropDownButton1});
            this.statusStrip1.Location = new System.Drawing.Point(0, 428);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(800, 22);
            this.statusStrip1.TabIndex = 6;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // status_user
            // 
            this.status_user.Name = "status_user";
            this.status_user.Size = new System.Drawing.Size(0, 17);
            // 
            // status_prog
            // 
            this.status_prog.Name = "status_prog";
            this.status_prog.Size = new System.Drawing.Size(100, 16);
            // 
            // status_saat
            // 
            this.status_saat.Name = "status_saat";
            this.status_saat.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStripDropDownButton1
            // 
            this.toolStripDropDownButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripDropDownButton1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu3ToolStripMenuItem,
            this.menu2ToolStripMenuItem,
            this.menu1ToolStripMenuItem});
            this.toolStripDropDownButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton1.Image")));
            this.toolStripDropDownButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton1.Name = "toolStripDropDownButton1";
            this.toolStripDropDownButton1.Size = new System.Drawing.Size(29, 20);
            this.toolStripDropDownButton1.Text = "toolStripDropDownButton1";
            // 
            // menu1ToolStripMenuItem
            // 
            this.menu1ToolStripMenuItem.Name = "menu1ToolStripMenuItem";
            this.menu1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menu1ToolStripMenuItem.Text = "Menu1";
            this.menu1ToolStripMenuItem.Click += new System.EventHandler(this.menu1ToolStripMenuItem_Click);
            // 
            // menu2ToolStripMenuItem
            // 
            this.menu2ToolStripMenuItem.Name = "menu2ToolStripMenuItem";
            this.menu2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menu2ToolStripMenuItem.Text = "Menu2";
            // 
            // menu3ToolStripMenuItem
            // 
            this.menu3ToolStripMenuItem.Name = "menu3ToolStripMenuItem";
            this.menu3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.menu3ToolStripMenuItem.Text = "Menu3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.lbprog);
            this.Controls.Add(this.pr1);
            this.Controls.Add(this.lbtrack);
            this.Controls.Add(this.track1);
            this.Controls.Add(this.lb1);
            this.Controls.Add(this.txt1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.track1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.TrackBar track1;
        private System.Windows.Forms.Label lbtrack;
        private System.Windows.Forms.ProgressBar pr1;
        private System.Windows.Forms.Label lbprog;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel status_user;
        private System.Windows.Forms.ToolStripProgressBar status_prog;
        private System.Windows.Forms.ToolStripStatusLabel status_saat;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton1;
        private System.Windows.Forms.ToolStripMenuItem menu3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem;
    }
}

