﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
//proje için project-nuget-install newtonsoft yap

namespace _14._3
{
    //https://app.currencyapi.com/request-playground
    //https://json2csharp.com/
    //https://api.openweathermap.org/data/2.5/weather?q=Ankara&appid=6fdbfb3be236fd19b5f4fb9fa956c236
    //https://openweathermap.org/current#cityid
    //DOVİZ KURUNU ANLIK TAKİP ETMEK-currencyapi
    //https://app.currencyapi.com/request-playground
    //convert json to c# tarayıcıdan aç
    //currency converter
    //api
    public partial class Form1 : Form
    {
        //json to c#
        // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse);
        public class CAD
        {
            public string code { get; set; }
            public double value { get; set; }
        }

        public class Data
        {
            public CAD CAD { get; set; }
            public EUR EUR { get; set; }
            public TRY TRY { get; set; }
            public USD USD { get; set; }
        }

        public class EUR
        {
            public string code { get; set; }
            public double value { get; set; }
        }

        public class Meta
        {
            public DateTime last_updated_at { get; set; }
        }

        public class Root
        {
            public Meta meta { get; set; }
            public Data data { get; set; }
        }

        public class TRY
        {
            public string code { get; set; }
            public double value { get; set; }
        }

        public class USD
        {
            public string code { get; set; }
            public int value { get; set; }
        }
  


    public Form1()
        {
            InitializeComponent();
        }
        public Root GetCurrency()
        {
            Root para = new Root();
            string Url = "https://api.currencyapi.com/v3/latest?apikey=SncpCF4wgKHLUNQL5nsKh7tRmyhY6FZWDbxJooOB&currencies=EUR%2CUSD%2CCAD%2CTRY";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            try
            {
                WebResponse response = request.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    string responseString = reader.ReadToEnd();
                    para = JsonConvert.DeserializeObject<Root>(responseString);
                }
            }
            catch (Exception)
            {

            }
            return para;
        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btn_cevir_Click(object sender, EventArgs e)
        {
            Root myPara=new Root();
            myPara=GetCurrency();
            label1.Text = myPara.data.CAD.code + " " + myPara.data.CAD.value;
            label2.Text = myPara.data.EUR.code + " " + myPara.data.EUR.value;
            label3.Text = myPara.data.TRY.code + " " + myPara.data.TRY.value;
            label4.Text = myPara.data.USD.code + " " + myPara.data.USD.value;
        }
    }
}
