﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;

namespace _14._2
{
    //api çağırma
    //rapid api  --open weather
    //currency api'den api kullanılabilir
    //tools-nugets-newtonsoft json
    //internetten veri alma, api
    //weather

    public partial class Form1 : Form
    {
        public class Clouds
        {
            public int all { get; set; }
        }

        public class Coord
        {
            public double lon { get; set; }
            public double lat { get; set; }
        }

        public class Main
        {
            public double temp { get; set; }
            public double feels_like { get; set; }
            public double temp_min { get; set; }
            public double temp_max { get; set; }
            public int pressure { get; set; }
            public int humidity { get; set; }
        }

        public class Rain
        {
            [JsonProperty("1h")]
            public double _1h { get; set; }
        }

        public class Root
        {
            public Coord coord { get; set; }
            public List<Weather> weather { get; set; }
            public string @base { get; set; }
            public Main main { get; set; }
            public int visibility { get; set; }
            //public Wind wind { get; set; }
            public Rain rain { get; set; }
            public Clouds clouds { get; set; }
            public int dt { get; set; }
            public Sys sys { get; set; }
            public int timezone { get; set; }
            public int id { get; set; }
            public string name { get; set; }
            public int cod { get; set; }
        }

        public class Sys
        {
            public int type { get; set; }
            public int id { get; set; }
            public string country { get; set; }
            public int sunrise { get; set; }
            public int sunset { get; set; }
        }

        public class Weather
        {
            public int id { get; set; }
            public string main { get; set; }
            public string description { get; set; }
            public string icon { get; set; }
        }

        public Root GetWeather(string city)
        {
            Root hava = new Root();
            string Url = "https://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=6fdbfb3be236fd19b5f4fb9fa956c236";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(Url);
            try
            {
                WebResponse response = request.GetResponse();
                using (Stream responseStream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(responseStream, Encoding.UTF8);
                    string responseString = reader.ReadToEnd();
                    hava = JsonConvert.DeserializeObject<Root>(responseString);
                }
            }
            catch (Exception)
            {

            }
            return hava;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Root myHava = GetWeather("Ankara");
            int a = 90;
        }

        private void btn_getir_Click(object sender, EventArgs e)
        {
            Root myHava = GetWeather(txt_city.Text);
            label1.Text = myHava.name;
            label2.Text = myHava.weather[0].description;

        }
    }
}
