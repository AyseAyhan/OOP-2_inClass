﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
//using SoapConsume.ServiceReference1;

namespace _11._5_wform
{
    //Asp.net WEBB APP

	 //[WebMethod] keywordu olmazsa okumaz-asp de

    //webb sayfası adresi eklenmeli
    //add -service reference a adres eklenmeli
    //değişikliklerin algılanması mümkün değil, proje update edilmeli
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            WebService1SoapClient client = new WebService1SoapClient();
            label1.Text = client.HelloWorld();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            WebService1SoapClient client = new WebService1SoapClient();
            label2.Text = client.HelloWorld();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            WebService1SoapClient client = new WebService1SoapClient();
            label3.Text=client.SayiTopla(int.Parse(textBox2.Text), int.Parse(textBox3.Text)).ToString();
        }
    }
}
