﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._4
{

    abstract class Page
    {

    }

    class SkillsPage : Page
    {

    }

    class EducationalPage:Page 
    { 
    
    }

    class ExperiencePage : Page
    {

    }
    class IntroductionPage : Page
    {

    }

    class ResultPage: Page
    {

    }
    class ConclusionPage : Page
    {

    }
    class SummaryPage:Page
    {

    }

    class BibliographyPage:Page
    {

    }

    abstract class Document
    {

        private List<Page>pages=new List<Page>();

        public Document() {
            this.CreatePages();
        }   

        public List<Page> Pages
        {
            get { return pages; }
        }

        public abstract void CreatePages();
    }

    class Resume : Document
    {
        public override void CreatePages()
        {
            Pages.Add(new SkillsPage());
            Pages.Add(new EducationalPage());
            Pages.Add(new  ExperiencePage());
          
        }
    }

    class Report : Document
    {
        public override void CreatePages()
        {
            Pages.Add(new IntroductionPage());
            Pages.Add(new ResultPage());
            Pages.Add(new ConclusionPage());
            Pages.Add(new SummaryPage());
            Pages.Add(new BibliographyPage());
        } 
    }

    class myReportType : Document
    {
        public override void CreatePages()
        {
            Pages.Add(new IntroductionPage());
        }
    }



    internal class Program
    {
        static void Main(string[] args)
        {
            Resume myresume = new Resume();
            foreach(Page page in myresume.Pages) 
            {
               Console.WriteLine(page.GetType().Name);
              
            }
            Console.WriteLine("-------------");
            Report myreport= new Report();
            foreach(Page page in myreport.Pages)
            {
                Console.WriteLine($"{page.GetType().Name}");
                
            }
     
            Console.WriteLine("-------------");
            myReportType myReportType=new myReportType();
            foreach (Page page in myReportType.Pages)
            {
                Console.WriteLine($"{page.GetType().Name}");

            }
            Console.ReadLine(); //bundan sonrasını okumaz
        }
    }
}
