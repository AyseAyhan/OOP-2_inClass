﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._3
{
    //ENUM
    //OYUNLAR
    //DESIGN PATTERN
    //abstract class
    enum Games
    {
        Atari,
        PC,
        PS
    }

    abstract class Game
    {
        public abstract void Platform();
    }

    class Atari: Game
    {
        public override void Platform()
        {
            Console.WriteLine("This game just work on Atari platfom.");
        }
    }

    class PC : Game
    {
        public override void Platform()
        {
            Console.WriteLine("This game just work on PC platform.");
        }

    }

    class PS : Game
    {
        public override void Platform()
        {
            Console.WriteLine("This game just work on PS platform.");
        }
    }

    class CreateGame
    {
        //enum old. için switch caseile daha ugun
        public Game FactortyMethod(Games gameverse)
        {
            Game game = null;

            switch(gameverse)
            {
                case Games.Atari:
                    game=new Atari();
                    break;
                case Games.PC:
                    game=new PC();
                    break;
                case Games.PS:
                    game=new PS();
                    break;
                default:
                    break;

            }
            return game;

        }

    }

    internal class Program
    {
        static void Main(string[] args)
        {
            CreateGame creategame = new CreateGame();
            Game atariGame= creategame.FactortyMethod(Games.Atari);
            atariGame.Platform();


            Game pcGame= creategame.FactortyMethod(Games.PC);
            pcGame.Platform();
          

            Game psGame=creategame.FactortyMethod(Games.PS);
            psGame.Platform();

            Console.ReadLine();//hemen kapanmaması için
        }
    }
}
