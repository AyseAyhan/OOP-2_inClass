﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._1
{
    //Design Pattern
    internal class Singleton
    {
        private static Singleton nesne;

        public static Singleton NesneYarat()
        {
            if(nesne==null )
            {
                nesne= new Singleton();
            }
            return nesne;
        }
    }
}
