﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._1
{
    //Design Patterns
    //nesnelerin eşitliği kontrolü 3 yöntem:
    //1: doğrudan nesne1==nesne2
    //2: nesne1.Equals(nesne2)  Equals fonksiyonu
    //3: nesne1.GetHashCode()==nesne2.GetHashCode()
    internal class Program
    {
        static void Main(string[] args)
        {
            Singleton sng1 = Singleton.NesneYarat();
            Singleton sng2= Singleton.NesneYarat();

            if(sng1==sng2)
            {
                Console.WriteLine("sng1 object is equal to snq2 object//method 1");

            }
            if(sng1.Equals(sng2))
            {
                Console.WriteLine("sng1 EQUAL sng2//METHOD2");
            }
            if(sng1.GetHashCode() == sng2.GetHashCode()) {

                Console.WriteLine("sng1 EQUAL sng2//method3");
            }

            Console.WriteLine("__________________________________");
            Console.WriteLine("----------------------------------");
            Esya esya1= new Esya();
            Esya esya2= new Esya();

            if(esya1.GetHashCode() == esya2.GetHashCode())
            {

                Console.WriteLine("Esya1=Esya2");
            }
            else
            {
                Console.WriteLine("Esya1 != Esya2");
            }
            Console.ReadLine(); // Konsolun kapanmasını engellemek için kullanıcıdan bir giriş bekliyoruz
        }
    }
}
