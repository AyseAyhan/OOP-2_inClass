﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _11._1
{
    internal class Esya
    {
        private float agirlik;

        public float Agirlik
        {

            get { return agirlik; }
            set { agirlik = value; }






        }
    }
}
