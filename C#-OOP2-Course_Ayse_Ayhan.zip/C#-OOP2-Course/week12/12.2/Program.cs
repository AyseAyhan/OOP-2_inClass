﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static _12._2.HouseTemplate;

namespace _12._2
{
    //DESIGN PATTERNS

    public abstract class HouseTemplate
    {
        protected abstract void BuildFoundation();
        protected abstract void BuildPillars();
        protected abstract void BuildWalls();
        protected abstract void BuildWindows();
       
        public void BuildHouse()
        {
            Console.WriteLine("Started to Build House");
            BuildFoundation();
            BuildPillars();
            BuildWalls();
            BuildWindows();
            Console.WriteLine("Finished to Build House");
        }

        public class ConcreteHouse:HouseTemplate 
        { 
           protected override void BuildFoundation()
            {
                Console.WriteLine("Building the foundation using cement iron and sand");

            }
            protected override void BuildPillars()
            {
                Console.WriteLine("Building the pillars using stone and iron");
            }

            protected override void BuildWalls()
            {
                Console.WriteLine("Building the walls using cement and sand");
            }
            protected override void BuildWindows()
            {
                Console.WriteLine("Building the windows using glass");
            }

        }

        public class WoodenHouse: HouseTemplate
        {//show actions tan otomatik şablon da yapılabilir
            protected override void BuildFoundation()
            {
                Console.WriteLine("Foundation: iron-sand");
            }

            protected override void BuildPillars()
            {
                Console.WriteLine("Pillars: wooden coating");
            }

            protected override void BuildWalls()
            {
                Console.WriteLine("Walls: wood");
            }
            protected override void BuildWindows()
            {
                Console.WriteLine("Windows: Glass");
            }



        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("I am Building a Concrete House");
            HouseTemplate betonarme = new ConcreteHouse();
            betonarme.BuildHouse();
            Console.WriteLine("*********************");
            Console.WriteLine("I am Building a Wooden House");
            HouseTemplate ahsap = new WoodenHouse();
            ahsap.BuildHouse();

            Console.ReadLine();
        }
    }
}
