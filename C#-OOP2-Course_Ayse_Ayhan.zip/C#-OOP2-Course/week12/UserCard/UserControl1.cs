﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UserCard
{
    public partial class UserControl1: UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
        }
////manipüle etmek için iki yöntem
////1: component-Properties-modifiers-public
////2: method ile
        
        public void SetUserCard(string Ad, string Soyad, bool kadinmi)
        {
            txt_ad.Text = Ad;
            txt_soyad.Text = Soyad;
            if(kadinmi)
            {
                rb_kadin.Checked = true;
            }
            else
            {
                rb_erkek.Checked = true;
            }

          //  pictureBox1.Image = Image.FromFile(@"C:\\Users\\90537\\Desktop\\2.Dönem Dersleri\\OOP_2\\Lesson\\week12\\UserCard\\bin\\Debug\Resim\");
      
        }
        
    }
}
