﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._3_Observer_Pattern
{
    //observer pattern

    abstract public class Observer
    {
        public abstract void Update();
    }

    public class BabaObserver : Observer
    {

        public override void Update()
        {
            Console.WriteLine("Ogrencinin derse katılmadığı babaya bildirildi");
        }
    }

    public class AnneObserver : Observer
    {
        public override void Update()
        {
            Console.WriteLine("Ogrencinin derse katılmadığı anneye bildirildi");
        }
    }
    public class OgretmenObserver: Observer
    {
        public override void Update()
        {
            Console.WriteLine("Ogrencinin derse katılmadığı öğretmene bildirildi");
        }
    }

    class Ogrenci
    {
       public string Ad { get; set; }
        public string Soyad { get; set; }
        public int Sinif { get; set; }

        bool derseKatilmadimi;

        public bool DerseKatilmadidimi
        {
            get { return derseKatilmadimi; }
            set
            {
                if (value == true)
                {

                    notify();
                    derseKatilmadimi = value;
                }
                else
                {
                    derseKatilmadimi = value;
                }
            }
        }

        List<Observer> Gozlemciler;

        public Ogrenci()
        {
            Gozlemciler = new List<Observer>();
        }

        public void ObserverEkle(Observer o)
        {
            Gozlemciler.Add(o);
        }

        public void ObserverCıkar(Observer o)
        {
            Gozlemciler.Remove(o);
        }

        public void notify()
        {
            foreach(Observer observer in Gozlemciler)
            {
                observer.Update();
            }
        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            Ogrenci ogrenci=new Ogrenci();
            ogrenci.Ad = "Ayse";
            ogrenci.Soyad = "Ayhan";
            ogrenci.Sinif = 3;
            
            BabaObserver baba= new BabaObserver();
            ogrenci.ObserverEkle(baba);

            AnneObserver anne = new AnneObserver();
            ogrenci.ObserverEkle(anne);

            OgretmenObserver ogretmen= new OgretmenObserver();
            ogrenci.ObserverEkle(ogretmen);
            ogrenci.DerseKatilmadidimi = true;


            Console.WriteLine("Ogretmen takibi bıraltı.");
            ogrenci.ObserverCıkar(ogretmen);
            ogrenci.DerseKatilmadidimi = true;

            //ogrenci.DerseKatilmadidimi = false;


            Console.ReadLine();
        }
    }
}
