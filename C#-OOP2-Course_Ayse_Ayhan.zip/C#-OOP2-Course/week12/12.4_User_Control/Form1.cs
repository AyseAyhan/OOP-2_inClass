﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _12._4_User_Control
{
    //User Control'ler
    //Kendi componentini oluşturmak
    //Toplu bir değişiklik istendiğinde tek- temel UserControl componenti sayesinde hepsi güncellenir
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            person1.SetUserCard("Ayse", "Ayhan", true);
            person2.SetUserCard("Holland", "Hawkins", false);
        
        }
    }
}
