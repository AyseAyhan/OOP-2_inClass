﻿namespace _12._4_User_Control
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.person1 = new UserCard.UserControl1();
            this.person2 = new UserCard.UserControl1();
            this.SuspendLayout();
            // 
            // person1
            // 
            this.person1.BackColor = System.Drawing.Color.Bisque;
            this.person1.Location = new System.Drawing.Point(12, 12);
            this.person1.Name = "person1";
            this.person1.Size = new System.Drawing.Size(475, 173);
            this.person1.TabIndex = 0;
            // 
            // person2
            // 
            this.person2.BackColor = System.Drawing.Color.Bisque;
            this.person2.Location = new System.Drawing.Point(13, 192);
            this.person2.Name = "person2";
            this.person2.Size = new System.Drawing.Size(474, 227);
            this.person2.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.person2);
            this.Controls.Add(this.person1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private UserCard.UserControl1 person1;
        private UserCard.UserControl1 person2;
    }
}

