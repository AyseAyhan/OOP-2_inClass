﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _12._1_Design_Patterns
{
    internal class Program
    {
        public abstract class DataAccessor
        {
            public abstract void Connect();
            public abstract void Select();

            public abstract void Process(int top);

            public abstract void Disconnect();

            public void Run(int top_N_Element)
            {
                Connect();
                Select();
                Process(top_N_Element);
                Disconnect();
            }

        }

        public class Categories: DataAccessor
        {
            private List<string> categories;
            public override void Connect()
            {
                categories = new List<string>();
            }
            public override void Select()
            {
                categories.Add("Kategori1");
                categories.Add("Kategori2");
                categories.Add("Kategori3");
                categories.Add("Kategori4");
                categories.Add("Kategori5");
            }

            public override void Process(int top_NthElement) 
            {
                Console.WriteLine("Categories Are Listing");
                for(int i=0; i<top_NthElement;i++)
                {
                    Console.WriteLine(categories[i]);
                }
                    Console.WriteLine("Categories listing has finished");
            }
            public override void Disconnect() 
            {
                categories.Clear();
            }
        }
        
        public class Products: DataAccessor
        {
            private List <string> products;
            public override void Connect()
            {
                products = new List<string>();
            }

            public override void Select()
            {
                products.Add("Product1");
                products.Add("Product2");
                products.Add("Product3");
                products.Add("Product4");
                products.Add("Product5");
            }
            public override void Process(int top)
            {
                Console.WriteLine("Products are listing");
                for(int i=0; i<top;i++)
                {
                    Console.WriteLine(products[i]);
                }
                Console.WriteLine("Products listing has finished");
            }
            public override void Disconnect() 
            { 
               products.Clear();
            }
        }
        static void Main(string[] args)
        {
            DataAccessor categories=new Categories();
            categories.Run(4);
            Console.WriteLine("*****************");
            DataAccessor product=new Products();
            product.Run(5);
            Console.ReadLine();
        }
       
    }
}
