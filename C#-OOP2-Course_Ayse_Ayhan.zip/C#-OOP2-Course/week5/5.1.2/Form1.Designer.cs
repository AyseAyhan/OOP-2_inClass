﻿namespace _5._1._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rbsecim1 = new System.Windows.Forms.RadioButton();
            this.rbsecim2 = new System.Windows.Forms.RadioButton();
            this.rbsecim3 = new System.Windows.Forms.RadioButton();
            this.cbcorap = new System.Windows.Forms.CheckBox();
            this.cbayakkabi = new System.Windows.Forms.CheckBox();
            this.cbPantolon = new System.Windows.Forms.CheckBox();
            this.lbara_toplam = new System.Windows.Forms.Label();
            this.label_indirim = new System.Windows.Forms.Label();
            this.label_tutar = new System.Windows.Forms.Label();
            this.rb_Kadın = new System.Windows.Forms.RadioButton();
            this.rb_Erkek = new System.Windows.Forms.RadioButton();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown3 = new System.Windows.Forms.NumericUpDown();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).BeginInit();
            this.SuspendLayout();
            // 
            // rbsecim1
            // 
            this.rbsecim1.AutoSize = true;
            this.rbsecim1.Checked = true;
            this.rbsecim1.Location = new System.Drawing.Point(6, 39);
            this.rbsecim1.Name = "rbsecim1";
            this.rbsecim1.Size = new System.Drawing.Size(77, 17);
            this.rbsecim1.TabIndex = 0;
            this.rbsecim1.TabStop = true;
            this.rbsecim1.Text = "İndirim Yok";
            this.rbsecim1.UseVisualStyleBackColor = true;
            this.rbsecim1.CheckedChanged += new System.EventHandler(this.rbsecim1_CheckedChanged);
            // 
            // rbsecim2
            // 
            this.rbsecim2.AutoSize = true;
            this.rbsecim2.Location = new System.Drawing.Point(6, 74);
            this.rbsecim2.Name = "rbsecim2";
            this.rbsecim2.Size = new System.Drawing.Size(78, 17);
            this.rbsecim2.TabIndex = 1;
            this.rbsecim2.Text = "İndirim %10";
            this.rbsecim2.UseVisualStyleBackColor = true;
            this.rbsecim2.CheckedChanged += new System.EventHandler(this.rbsecim2_CheckedChanged);
            // 
            // rbsecim3
            // 
            this.rbsecim3.AutoSize = true;
            this.rbsecim3.Location = new System.Drawing.Point(6, 110);
            this.rbsecim3.Name = "rbsecim3";
            this.rbsecim3.Size = new System.Drawing.Size(78, 17);
            this.rbsecim3.TabIndex = 2;
            this.rbsecim3.Text = "İndirim %20";
            this.rbsecim3.UseVisualStyleBackColor = true;
            this.rbsecim3.CheckedChanged += new System.EventHandler(this.rbsecim3_CheckedChanged);
            // 
            // cbcorap
            // 
            this.cbcorap.AutoSize = true;
            this.cbcorap.Location = new System.Drawing.Point(6, 42);
            this.cbcorap.Name = "cbcorap";
            this.cbcorap.Size = new System.Drawing.Size(77, 17);
            this.cbcorap.TabIndex = 3;
            this.cbcorap.Text = "Çorap 10 tl";
            this.cbcorap.UseVisualStyleBackColor = true;
            this.cbcorap.CheckedChanged += new System.EventHandler(this.cbcorap_CheckedChanged);
            // 
            // cbayakkabi
            // 
            this.cbayakkabi.AutoSize = true;
            this.cbayakkabi.Location = new System.Drawing.Point(6, 65);
            this.cbayakkabi.Name = "cbayakkabi";
            this.cbayakkabi.Size = new System.Drawing.Size(93, 17);
            this.cbayakkabi.TabIndex = 4;
            this.cbayakkabi.Text = "Ayakkabı 30 tl";
            this.cbayakkabi.UseVisualStyleBackColor = true;
            this.cbayakkabi.CheckedChanged += new System.EventHandler(this.cbayakkabi_CheckedChanged);
            // 
            // cbPantolon
            // 
            this.cbPantolon.AutoSize = true;
            this.cbPantolon.Location = new System.Drawing.Point(6, 89);
            this.cbPantolon.Name = "cbPantolon";
            this.cbPantolon.Size = new System.Drawing.Size(91, 17);
            this.cbPantolon.TabIndex = 5;
            this.cbPantolon.Text = "Pantolon 20 tl";
            this.cbPantolon.UseVisualStyleBackColor = true;
            this.cbPantolon.CheckedChanged += new System.EventHandler(this.cbPantolon_CheckedChanged);
            // 
            // lbara_toplam
            // 
            this.lbara_toplam.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbara_toplam.Location = new System.Drawing.Point(23, 258);
            this.lbara_toplam.Name = "lbara_toplam";
            this.lbara_toplam.Size = new System.Drawing.Size(93, 15);
            this.lbara_toplam.TabIndex = 6;
            this.lbara_toplam.Text = "Ara Toplam";
            // 
            // label_indirim
            // 
            this.label_indirim.AutoSize = true;
            this.label_indirim.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_indirim.Location = new System.Drawing.Point(23, 291);
            this.label_indirim.Name = "label_indirim";
            this.label_indirim.Size = new System.Drawing.Size(93, 15);
            this.label_indirim.TabIndex = 7;
            this.label_indirim.Text = "İndirim Tutarı";
            // 
            // label_tutar
            // 
            this.label_tutar.AutoSize = true;
            this.label_tutar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label_tutar.Location = new System.Drawing.Point(23, 324);
            this.label_tutar.Name = "label_tutar";
            this.label_tutar.Size = new System.Drawing.Size(66, 15);
            this.label_tutar.TabIndex = 8;
            this.label_tutar.Text = "Net Tutar";
            // 
            // rb_Kadın
            // 
            this.rb_Kadın.AutoSize = true;
            this.rb_Kadın.Checked = true;
            this.rb_Kadın.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rb_Kadın.Location = new System.Drawing.Point(6, 48);
            this.rb_Kadın.Name = "rb_Kadın";
            this.rb_Kadın.Size = new System.Drawing.Size(62, 19);
            this.rb_Kadın.TabIndex = 9;
            this.rb_Kadın.TabStop = true;
            this.rb_Kadın.Text = "Kadın";
            this.rb_Kadın.UseVisualStyleBackColor = true;
            // 
            // rb_Erkek
            // 
            this.rb_Erkek.AutoSize = true;
            this.rb_Erkek.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rb_Erkek.Location = new System.Drawing.Point(6, 94);
            this.rb_Erkek.Name = "rb_Erkek";
            this.rb_Erkek.Size = new System.Drawing.Size(61, 19);
            this.rb_Erkek.TabIndex = 10;
            this.rb_Erkek.Text = "Erkek";
            this.rb_Erkek.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbsecim2);
            this.groupBox1.Controls.Add(this.rbsecim1);
            this.groupBox1.Controls.Add(this.rbsecim3);
            this.groupBox1.Location = new System.Drawing.Point(249, 23);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(201, 163);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "İndirim Oranı";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rb_Erkek);
            this.groupBox2.Controls.Add(this.rb_Kadın);
            this.groupBox2.Location = new System.Drawing.Point(492, 23);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(201, 163);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Cinsiyet";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.numericUpDown3);
            this.groupBox3.Controls.Add(this.numericUpDown2);
            this.groupBox3.Controls.Add(this.numericUpDown1);
            this.groupBox3.Controls.Add(this.cbcorap);
            this.groupBox3.Controls.Add(this.cbayakkabi);
            this.groupBox3.Controls.Add(this.cbPantolon);
            this.groupBox3.Location = new System.Drawing.Point(6, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(201, 163);
            this.groupBox3.TabIndex = 13;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Ürünler";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Location = new System.Drawing.Point(125, 39);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(52, 20);
            this.numericUpDown1.TabIndex = 14;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Location = new System.Drawing.Point(125, 67);
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.Size = new System.Drawing.Size(52, 20);
            this.numericUpDown2.TabIndex = 15;
            // 
            // numericUpDown3
            // 
            this.numericUpDown3.Location = new System.Drawing.Point(125, 95);
            this.numericUpDown3.Name = "numericUpDown3";
            this.numericUpDown3.Size = new System.Drawing.Size(52, 20);
            this.numericUpDown3.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label_tutar);
            this.Controls.Add(this.label_indirim);
            this.Controls.Add(this.lbara_toplam);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton rbsecim1;
        private System.Windows.Forms.RadioButton rbsecim2;
        private System.Windows.Forms.RadioButton rbsecim3;
        private System.Windows.Forms.CheckBox cbcorap;
        private System.Windows.Forms.CheckBox cbayakkabi;
        private System.Windows.Forms.CheckBox cbPantolon;
        private System.Windows.Forms.Label lbara_toplam;
        private System.Windows.Forms.Label label_indirim;
        private System.Windows.Forms.Label label_tutar;
        private System.Windows.Forms.RadioButton rb_Kadın;
        private System.Windows.Forms.RadioButton rb_Erkek;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.NumericUpDown numericUpDown3;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
    }
}

