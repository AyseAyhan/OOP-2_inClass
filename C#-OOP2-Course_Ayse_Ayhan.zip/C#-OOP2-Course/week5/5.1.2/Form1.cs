﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5._1._2
{
    //radiobutton, checkbox  farkı: checkbox'ta birden fazla seçenek seçilebilir
    //groupbox
    public partial class Form1 : Form
    {
        double AraToplam = 0;
        double İndirimOrani = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void rbsecim1_CheckedChanged(object sender, EventArgs e)
        {
            
            if (rbsecim1.Checked )
            {
                MessageBox.Show("Seçim 1 seçili");
            }
        }

        private void rbsecim2_CheckedChanged(object sender, EventArgs e)
        {
            if(rbsecim2.Checked )
            {
                MessageBox.Show("Seçim 2 seçili");
            }
        }

        private void rbsecim3_CheckedChanged(object sender, EventArgs e)
        {
            if(rbsecim3.Checked )
            {
                MessageBox.Show("Seçim 3 seçildi");
            }
        }
        private void SecimiKontrolet()
        {
            if (cbcorap.Checked)
            {
                MessageBox.Show("Çorap Seçili");
            }
            else
            {
                MessageBox.Show("Çorap Seçili Değil");
            }
            if (cbayakkabi.Checked)
            {
                MessageBox.Show("Ayakkabı Seçili");
            }
            else
            {
                MessageBox.Show("Ayakkabı Seçili Değil");
            }
            if(cbPantolon.Checked)
            {
                MessageBox.Show("Pantolon Seçili");
            }
            else
            {
                MessageBox.Show("Pantolon Seçili Değil.");
            }
        }

        double indirimoraniGetir()
        {
            if (rbsecim1.Checked)
            {
                İndirimOrani = 0;
            }
            else if(rbsecim2.Checked)
            {
                İndirimOrani = 10;
            }
            else
            {
                İndirimOrani = 20;
            }
            return İndirimOrani;
            
        }

        private void cbcorap_CheckedChanged(object sender, EventArgs e)
        {
    
           // SecimiKontrolet();
           if(cbcorap.Checked )
            {
                AraToplam += 10;
            }
            else
            {
                AraToplam -= 10;
            }
            lbara_toplam.Text = AraToplam.ToString("c");
            label_indirim.Text = (AraToplam*(indirimoraniGetir()/100)).ToString("c");
            label_tutar.Text = (AraToplam - İndirimOrani).ToString("c");
        }

        private void cbayakkabi_CheckedChanged(object sender, EventArgs e)
        {
           // SecimiKontrolet();
           if(cbayakkabi.Checked )
            {
                AraToplam += 30;
            }
            else
            {
                AraToplam-=30;
            }
           lbara_toplam.Text=AraToplam.ToString("c");
            label_indirim.Text = (AraToplam * (indirimoraniGetir() / 100)).ToString("c");
            label_tutar.Text = (AraToplam - İndirimOrani).ToString("c");
        }

        private void cbPantolon_CheckedChanged(object sender, EventArgs e)
        {
            // SecimiKontrolet();
            if (cbPantolon.Checked)
            {
                AraToplam += 20;
            }
            else
            {
                AraToplam -= 20;
            }
            lbara_toplam.Text=(AraToplam.ToString("c"));
            label_indirim.Text = (AraToplam * (indirimoraniGetir() / 100)).ToString("c");
            label_tutar.Text=(AraToplam-İndirimOrani).ToString("c");
        }

      
    }
}
