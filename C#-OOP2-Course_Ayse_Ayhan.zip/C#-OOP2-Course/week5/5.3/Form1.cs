﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5._3
{
    //ListView: kolonlar halinde listeyi gösterir
    //gridlines: true
    //view: details
    public partial class Form1 : Form
    {
        Kedi[] kediler;  //global
        int selectedRowIndex = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button_ekle_Click(object sender, EventArgs e)
        {
            string[] row = { "Kolon1", "Kolon2", "Kolon3" };
            ListViewItem listViewItem = new ListViewItem(row);
            listkedi.Items.Add(listViewItem);
        }

        private void btn_ekle2_Click(object sender, EventArgs e)
        {
            try
            {
                string Ad = textBox1.Text;
                string Cins = textBox2.Text;
                string Age = textBox3.Text;
                string[] row = { Ad, Cins, Age };
                ListViewItem viewitem = new ListViewItem(row);
                listkedi.Items.Add(viewitem);

            }
            catch(Exception)
            {

            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            kediler = new Kedi[3];
            kediler[0] =new Kedi("MırMır", "Scotish","8","scot.jpg");
            kediler[1] = new Kedi("Murekkep", "Tekir", "1", "tekir.jpg");
            kediler[2] = new Kedi("Yoda", "Sfenks", "4", "sfenks.jpg");


            for(int i=0;i<kediler.Length;i++)
            {
                string[] row = { kediler[i].Ad, kediler[i].Cins, kediler[i].Age, kediler[i].Resim };  //önemli
                ListViewItem viewitem = new ListViewItem(row);  //önemli
                listkedi.Items.Add(viewitem);
            }
        }
        private void listkedi_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text = listkedi.Items[listkedi.FocusedItem.Index].SubItems[0].Text;
                textBox2.Text = listkedi.Items[listkedi.FocusedItem.Index].SubItems[1].Text;
                textBox3.Text = listkedi.Items[listkedi.FocusedItem.Index].SubItems[2].Text;
                //textBox4.Text = listkedi.Items[listkedi.FocusedItem.Index].SubItems[3].Text;
                //selectionmode: fullrowselect-true
                pc_kedi.Image = Image.FromFile(@"..\..\cats\" + listkedi.Items[listkedi.FocusedItem.Index].SubItems[3].Text);
                //prop-size mode-stretch
                selectedRowIndex = listkedi.FocusedItem.Index;   //indis için

            }
            catch (Exception)
            {

            }

        }
        private void btn_change_Click(object sender, EventArgs e)
        {
            listkedi.Items[selectedRowIndex].SubItems[0].Text = textBox1.Text;  //arrayi değiştirmeden değişim yapılmış oldu
            listkedi.Items[selectedRowIndex].SubItems[1].Text = textBox2.Text;
            listkedi.Items[selectedRowIndex].SubItems[2].Text = textBox3.Text;

        }
    }
}
