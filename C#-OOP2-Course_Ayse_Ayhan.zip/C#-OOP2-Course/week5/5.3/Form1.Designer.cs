﻿namespace _5._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listkedi = new System.Windows.Forms.ListView();
            this.Ad = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Cins = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Yaş = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button_ekle = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.btn_ekle2 = new System.Windows.Forms.Button();
            this.Resim = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.pc_kedi = new System.Windows.Forms.PictureBox();
            this.btn_change = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pc_kedi)).BeginInit();
            this.SuspendLayout();
            // 
            // listkedi
            // 
            this.listkedi.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Ad,
            this.Cins,
            this.Yaş,
            this.Resim});
            this.listkedi.FullRowSelect = true;
            this.listkedi.GridLines = true;
            this.listkedi.HideSelection = false;
            this.listkedi.Location = new System.Drawing.Point(12, 29);
            this.listkedi.Name = "listkedi";
            this.listkedi.Size = new System.Drawing.Size(426, 362);
            this.listkedi.TabIndex = 0;
            this.listkedi.UseCompatibleStateImageBehavior = false;
            this.listkedi.View = System.Windows.Forms.View.Details;
            this.listkedi.SelectedIndexChanged += new System.EventHandler(this.listkedi_SelectedIndexChanged);
            // 
            // Ad
            // 
            this.Ad.Text = "Ad";
            this.Ad.Width = 110;
            // 
            // Cins
            // 
            this.Cins.Text = "Cins";
            this.Cins.Width = 110;
            // 
            // Yaş
            // 
            this.Yaş.Text = "Yaş";
            this.Yaş.Width = 90;
            // 
            // button_ekle
            // 
            this.button_ekle.BackColor = System.Drawing.Color.Bisque;
            this.button_ekle.Location = new System.Drawing.Point(494, 29);
            this.button_ekle.Name = "button_ekle";
            this.button_ekle.Size = new System.Drawing.Size(106, 46);
            this.button_ekle.TabIndex = 1;
            this.button_ekle.Text = "Ekle";
            this.button_ekle.UseVisualStyleBackColor = false;
            this.button_ekle.Click += new System.EventHandler(this.button_ekle_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(632, 25);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 2;
            this.textBox1.Text = "Ad";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(632, 59);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "Cins";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(632, 93);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 4;
            this.textBox3.Text = "Yaş";
            // 
            // btn_ekle2
            // 
            this.btn_ekle2.BackColor = System.Drawing.Color.PeachPuff;
            this.btn_ekle2.Location = new System.Drawing.Point(632, 174);
            this.btn_ekle2.Name = "btn_ekle2";
            this.btn_ekle2.Size = new System.Drawing.Size(75, 23);
            this.btn_ekle2.TabIndex = 5;
            this.btn_ekle2.Text = "Seçimi Ekle";
            this.btn_ekle2.UseVisualStyleBackColor = false;
            this.btn_ekle2.Click += new System.EventHandler(this.btn_ekle2_Click);
            // 
            // Resim
            // 
            this.Resim.Text = "Resim";
            this.Resim.Width = 120;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(632, 128);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 6;
            this.textBox4.Text = "Resim";
            // 
            // pc_kedi
            // 
            this.pc_kedi.BackColor = System.Drawing.Color.AntiqueWhite;
            this.pc_kedi.Location = new System.Drawing.Point(553, 239);
            this.pc_kedi.Name = "pc_kedi";
            this.pc_kedi.Size = new System.Drawing.Size(179, 152);
            this.pc_kedi.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pc_kedi.TabIndex = 7;
            this.pc_kedi.TabStop = false;
            // 
            // btn_change
            // 
            this.btn_change.BackColor = System.Drawing.Color.Bisque;
            this.btn_change.Location = new System.Drawing.Point(494, 102);
            this.btn_change.Name = "btn_change";
            this.btn_change.Size = new System.Drawing.Size(106, 46);
            this.btn_change.TabIndex = 8;
            this.btn_change.Text = "Değiştir";
            this.btn_change.UseVisualStyleBackColor = false;
            this.btn_change.Click += new System.EventHandler(this.btn_change_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_change);
            this.Controls.Add(this.pc_kedi);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.btn_ekle2);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.button_ekle);
            this.Controls.Add(this.listkedi);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pc_kedi)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listkedi;
        private System.Windows.Forms.ColumnHeader Ad;
        private System.Windows.Forms.ColumnHeader Cins;
        private System.Windows.Forms.ColumnHeader Yaş;
        private System.Windows.Forms.Button button_ekle;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Button btn_ekle2;
        private System.Windows.Forms.ColumnHeader Resim;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.PictureBox pc_kedi;
        private System.Windows.Forms.Button btn_change;
    }
}

