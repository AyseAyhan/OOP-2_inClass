﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5._3
{
    internal class Kedi
    {
        
        public Kedi(String ad, String cins,String age, String resim) { 
            Ad= ad; 
            Cins= cins;
            Age= age;
            Resim=resim;
        
        }   
        public string Ad
        {
            get;set;
        }
        public string Cins
        {
            get;set;
        }
        public string Age
        {
            get;set;
        }
        public string Resim
        {
            get;set;
        }
    }
}
