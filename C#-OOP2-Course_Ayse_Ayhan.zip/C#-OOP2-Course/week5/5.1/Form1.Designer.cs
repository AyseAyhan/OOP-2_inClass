﻿namespace _5._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.listEleman = new System.Windows.Forms.ListBox();
            this.btnsil = new System.Windows.Forms.Button();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.seçiliOlanlarıSilToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mesajKutusuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.formRenginiDeğiştirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formuKapatToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.maskedText = new System.Windows.Forms.MaskedTextBox();
            this.btn_oku = new System.Windows.Forms.Button();
            this.contextMenuStrip1.SuspendLayout();
            this.contextMenuStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // listEleman
            // 
            this.listEleman.ContextMenuStrip = this.contextMenuStrip2;
            this.listEleman.FormattingEnabled = true;
            this.listEleman.Location = new System.Drawing.Point(12, 33);
            this.listEleman.Name = "listEleman";
            this.listEleman.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listEleman.Size = new System.Drawing.Size(325, 368);
            this.listEleman.TabIndex = 0;
            // 
            // btnsil
            // 
            this.btnsil.Location = new System.Drawing.Point(408, 33);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(135, 69);
            this.btnsil.TabIndex = 1;
            this.btnsil.Text = "Eleman Sil";
            this.btnsil.UseVisualStyleBackColor = true;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.seçiliOlanlarıSilToolStripMenuItem,
            this.mesajKutusuToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(158, 48);
            // 
            // seçiliOlanlarıSilToolStripMenuItem
            // 
            this.seçiliOlanlarıSilToolStripMenuItem.Name = "seçiliOlanlarıSilToolStripMenuItem";
            this.seçiliOlanlarıSilToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.seçiliOlanlarıSilToolStripMenuItem.Text = "Seçili olanları sil";
            this.seçiliOlanlarıSilToolStripMenuItem.Click += new System.EventHandler(this.seçiliOlanlarıSilToolStripMenuItem_Click);
            // 
            // mesajKutusuToolStripMenuItem
            // 
            this.mesajKutusuToolStripMenuItem.Name = "mesajKutusuToolStripMenuItem";
            this.mesajKutusuToolStripMenuItem.Size = new System.Drawing.Size(157, 22);
            this.mesajKutusuToolStripMenuItem.Text = "Mesaj Kutusu";
            this.mesajKutusuToolStripMenuItem.Click += new System.EventHandler(this.mesajKutusuToolStripMenuItem_Click);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formRenginiDeğiştirToolStripMenuItem,
            this.formuKapatToolStripMenuItem});
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(189, 48);
            // 
            // formRenginiDeğiştirToolStripMenuItem
            // 
            this.formRenginiDeğiştirToolStripMenuItem.Name = "formRenginiDeğiştirToolStripMenuItem";
            this.formRenginiDeğiştirToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.formRenginiDeğiştirToolStripMenuItem.Text = "Form Rengini Değiştir";
            this.formRenginiDeğiştirToolStripMenuItem.Click += new System.EventHandler(this.formRenginiDeğiştirToolStripMenuItem_Click);
            // 
            // formuKapatToolStripMenuItem
            // 
            this.formuKapatToolStripMenuItem.Name = "formuKapatToolStripMenuItem";
            this.formuKapatToolStripMenuItem.Size = new System.Drawing.Size(188, 22);
            this.formuKapatToolStripMenuItem.Text = "Formu Kapat";
            this.formuKapatToolStripMenuItem.Click += new System.EventHandler(this.formuKapatToolStripMenuItem_Click);
            // 
            // maskedText
            // 
            this.maskedText.Location = new System.Drawing.Point(408, 122);
            this.maskedText.Mask = "(999) 000-0000";
            this.maskedText.Name = "maskedText";
            this.maskedText.Size = new System.Drawing.Size(173, 20);
            this.maskedText.TabIndex = 3;
            // 
            // btn_oku
            // 
            this.btn_oku.Location = new System.Drawing.Point(597, 122);
            this.btn_oku.Name = "btn_oku";
            this.btn_oku.Size = new System.Drawing.Size(120, 52);
            this.btn_oku.TabIndex = 4;
            this.btn_oku.Text = "OKU";
            this.btn_oku.UseVisualStyleBackColor = true;
            this.btn_oku.Click += new System.EventHandler(this.btn_oku_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btn_oku);
            this.Controls.Add(this.maskedText);
            this.Controls.Add(this.btnsil);
            this.Controls.Add(this.listEleman);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.contextMenuStrip2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listEleman;
        private System.Windows.Forms.Button btnsil;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem seçiliOlanlarıSilToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mesajKutusuToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        private System.Windows.Forms.ToolStripMenuItem formRenginiDeğiştirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formuKapatToolStripMenuItem;
        private System.Windows.Forms.MaskedTextBox maskedText;
        private System.Windows.Forms.Button btn_oku;
    }
}

