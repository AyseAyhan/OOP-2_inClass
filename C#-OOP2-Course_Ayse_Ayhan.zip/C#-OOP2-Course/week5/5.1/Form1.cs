﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _5._1
{
    //1: listbox-context menu-masktext
    //Konular: listbox, masktext, context menu, picturebox
    //listbox: selectionmode kısmından tek bir seçenek ya da daha fazla seçilme durumu ayarlanabilir
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           // listEleman.Items.Add("Eleman 1");
           for(int i = 0; i < 10; i++)
            {
                listEleman.Items.Add("Eleman "+(i+1));
            }

            maskedText.BackColor = Color.White;

        }
        private void btnsil_Click(object sender, EventArgs e)  //tekrar
        {
            for(int i=listEleman.SelectedIndices.Count-1;i>=0;i--)
            {
                int secili_indis = listEleman.SelectedIndices[i]; //önemli özellik: SelectedIndices
                listEleman.Items.RemoveAt(secili_indis);
            }
        }

        private void mesajKutusuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Mesaj Kutusu Gösterildi");
        }

        private void seçiliOlanlarıSilToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for(int i = listEleman.SelectedIndices.Count - 1; i >= 0; i--)
            {
                int secili_indis = listEleman.SelectedIndices[i];
                listEleman.Items.RemoveAt(secili_indis);
            }

        }

        private void formRenginiDeğiştirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.BackColor = Color.Aqua;  //this kullanılır!!!
            //this.BackColor = Color.LimeGreen;
            this.BackColor = Color.Lime;
        }

        private void formuKapatToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_oku_Click(object sender, EventArgs e)
        {
            if (maskedText.MaskFull)
            {
                MessageBox.Show("Şablon Doğru");
                maskedText.BackColor = Color.White;
            }
            else
            {
                maskedText.BackColor = Color.Red;
                MessageBox.Show("Yanlış Şablon");
            }
        }
    }
}
