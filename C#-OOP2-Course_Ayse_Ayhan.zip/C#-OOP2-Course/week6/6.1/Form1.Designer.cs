﻿namespace _6._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.chk_liste = new System.Windows.Forms.CheckedListBox();
            this.contextMenu1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.tümünüSeçToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.seçimiKaldırToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tersiniSeçToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btn_liste = new System.Windows.Forms.Button();
            this.txt_input = new System.Windows.Forms.TextBox();
            this.btn_sil = new System.Windows.Forms.Button();
            this.btn_clr = new System.Windows.Forms.Button();
            this.btn_sil2 = new System.Windows.Forms.Button();
            this.lb_hata = new System.Windows.Forms.Label();
            this.btn_all = new System.Windows.Forms.Button();
            this.btn_kaldir = new System.Windows.Forms.Button();
            this.btn_ters = new System.Windows.Forms.Button();
            this.button_delete = new System.Windows.Forms.Button();
            this.contextMenu1.SuspendLayout();
            this.SuspendLayout();
            // 
            // chk_liste
            // 
            this.chk_liste.ContextMenuStrip = this.contextMenu1;
            this.chk_liste.FormattingEnabled = true;
            this.chk_liste.Items.AddRange(new object[] {
            "1. Eleman",
            "2. Eleman",
            "3. Eleman",
            "4. Eleman"});
            this.chk_liste.Location = new System.Drawing.Point(2, 30);
            this.chk_liste.Name = "chk_liste";
            this.chk_liste.Size = new System.Drawing.Size(297, 409);
            this.chk_liste.TabIndex = 0;
            this.chk_liste.SelectedIndexChanged += new System.EventHandler(this.chk_liste_SelectedIndexChanged);
            // 
            // contextMenu1
            // 
            this.contextMenu1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tümünüSeçToolStripMenuItem,
            this.seçimiKaldırToolStripMenuItem,
            this.tersiniSeçToolStripMenuItem});
            this.contextMenu1.Name = "contextMenu1";
            this.contextMenu1.Size = new System.Drawing.Size(143, 70);
            // 
            // tümünüSeçToolStripMenuItem
            // 
            this.tümünüSeçToolStripMenuItem.Name = "tümünüSeçToolStripMenuItem";
            this.tümünüSeçToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.tümünüSeçToolStripMenuItem.Text = "Tümünü Seç";
            this.tümünüSeçToolStripMenuItem.Click += new System.EventHandler(this.tümünüSeçToolStripMenuItem_Click);
            // 
            // seçimiKaldırToolStripMenuItem
            // 
            this.seçimiKaldırToolStripMenuItem.Name = "seçimiKaldırToolStripMenuItem";
            this.seçimiKaldırToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.seçimiKaldırToolStripMenuItem.Text = "Seçimi Kaldır";
            this.seçimiKaldırToolStripMenuItem.Click += new System.EventHandler(this.seçimiKaldırToolStripMenuItem_Click);
            // 
            // tersiniSeçToolStripMenuItem
            // 
            this.tersiniSeçToolStripMenuItem.Name = "tersiniSeçToolStripMenuItem";
            this.tersiniSeçToolStripMenuItem.Size = new System.Drawing.Size(142, 22);
            this.tersiniSeçToolStripMenuItem.Text = "Tersini Seç";
            this.tersiniSeçToolStripMenuItem.Click += new System.EventHandler(this.tersiniSeçToolStripMenuItem_Click);
            // 
            // btn_liste
            // 
            this.btn_liste.Location = new System.Drawing.Point(305, 72);
            this.btn_liste.Name = "btn_liste";
            this.btn_liste.Size = new System.Drawing.Size(161, 23);
            this.btn_liste.TabIndex = 1;
            this.btn_liste.Text = "ELEMAN EKLE";
            this.btn_liste.UseVisualStyleBackColor = true;
            this.btn_liste.Click += new System.EventHandler(this.btn_liste_Click);
            // 
            // txt_input
            // 
            this.txt_input.Location = new System.Drawing.Point(305, 30);
            this.txt_input.Name = "txt_input";
            this.txt_input.Size = new System.Drawing.Size(147, 20);
            this.txt_input.TabIndex = 2;
            // 
            // btn_sil
            // 
            this.btn_sil.Location = new System.Drawing.Point(305, 101);
            this.btn_sil.Name = "btn_sil";
            this.btn_sil.Size = new System.Drawing.Size(161, 23);
            this.btn_sil.TabIndex = 3;
            this.btn_sil.Text = "INDEXTEKİ ELEMANI SİL";
            this.btn_sil.UseVisualStyleBackColor = true;
            this.btn_sil.Click += new System.EventHandler(this.btn_sil_Click);
            // 
            // btn_clr
            // 
            this.btn_clr.Location = new System.Drawing.Point(305, 159);
            this.btn_clr.Name = "btn_clr";
            this.btn_clr.Size = new System.Drawing.Size(161, 23);
            this.btn_clr.TabIndex = 4;
            this.btn_clr.Text = "TEMİZLE";
            this.btn_clr.UseVisualStyleBackColor = true;
            this.btn_clr.Click += new System.EventHandler(this.btn_clr_Click);
            // 
            // btn_sil2
            // 
            this.btn_sil2.Location = new System.Drawing.Point(305, 130);
            this.btn_sil2.Name = "btn_sil2";
            this.btn_sil2.Size = new System.Drawing.Size(161, 23);
            this.btn_sil2.TabIndex = 5;
            this.btn_sil2.Text = "ELEMAN SİL";
            this.btn_sil2.UseVisualStyleBackColor = true;
            this.btn_sil2.Click += new System.EventHandler(this.btn_sil2_Click);
            // 
            // lb_hata
            // 
            this.lb_hata.Location = new System.Drawing.Point(305, 197);
            this.lb_hata.Name = "lb_hata";
            this.lb_hata.Size = new System.Drawing.Size(192, 23);
            this.lb_hata.TabIndex = 6;
            // 
            // btn_all
            // 
            this.btn_all.Location = new System.Drawing.Point(305, 188);
            this.btn_all.Name = "btn_all";
            this.btn_all.Size = new System.Drawing.Size(161, 23);
            this.btn_all.TabIndex = 7;
            this.btn_all.Text = "TÜMÜNÜ SEÇ";
            this.btn_all.UseVisualStyleBackColor = true;
            this.btn_all.Click += new System.EventHandler(this.btn_all_Click);
            // 
            // btn_kaldir
            // 
            this.btn_kaldir.Location = new System.Drawing.Point(305, 217);
            this.btn_kaldir.Name = "btn_kaldir";
            this.btn_kaldir.Size = new System.Drawing.Size(161, 23);
            this.btn_kaldir.TabIndex = 8;
            this.btn_kaldir.Text = "SEÇİMİ KALDIR";
            this.btn_kaldir.UseVisualStyleBackColor = true;
            this.btn_kaldir.Click += new System.EventHandler(this.btn_kaldir_Click);
            // 
            // btn_ters
            // 
            this.btn_ters.Location = new System.Drawing.Point(308, 246);
            this.btn_ters.Name = "btn_ters";
            this.btn_ters.Size = new System.Drawing.Size(158, 23);
            this.btn_ters.TabIndex = 9;
            this.btn_ters.Text = "TERSİNİ SEÇ";
            this.btn_ters.UseVisualStyleBackColor = true;
            this.btn_ters.Click += new System.EventHandler(this.btn_ters_Click);
            // 
            // button_delete
            // 
            this.button_delete.Location = new System.Drawing.Point(308, 275);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(158, 23);
            this.button_delete.TabIndex = 10;
            this.button_delete.Text = "SEÇİMİ SİL";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.btn_ters);
            this.Controls.Add(this.btn_kaldir);
            this.Controls.Add(this.btn_all);
            this.Controls.Add(this.lb_hata);
            this.Controls.Add(this.btn_sil2);
            this.Controls.Add(this.btn_clr);
            this.Controls.Add(this.btn_sil);
            this.Controls.Add(this.txt_input);
            this.Controls.Add(this.btn_liste);
            this.Controls.Add(this.chk_liste);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.contextMenu1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox chk_liste;
        private System.Windows.Forms.Button btn_liste;
        private System.Windows.Forms.TextBox txt_input;
        private System.Windows.Forms.Button btn_sil;
        private System.Windows.Forms.Button btn_clr;
        private System.Windows.Forms.Button btn_sil2;
        private System.Windows.Forms.Label lb_hata;
        private System.Windows.Forms.Button btn_all;
        private System.Windows.Forms.Button btn_kaldir;
        private System.Windows.Forms.Button btn_ters;
        private System.Windows.Forms.ContextMenuStrip contextMenu1;
        private System.Windows.Forms.ToolStripMenuItem tümünüSeçToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem seçimiKaldırToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tersiniSeçToolStripMenuItem;
        private System.Windows.Forms.Button button_delete;
    }
}

