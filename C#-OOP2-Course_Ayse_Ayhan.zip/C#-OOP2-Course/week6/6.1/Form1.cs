﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void chk_liste_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_liste_Click(object sender, EventArgs e)
        {
            chk_liste.Items.Add(txt_input.Text);
            txt_input.Text = "";


        }
        private void btn_sil_Click(object sender, EventArgs e)
        {
            try
            {
                chk_liste.Items.RemoveAt(int.Parse(txt_input.Text));
                txt_input.Text = "";
            }
            catch(Exception ex)
            {
                //MessageBox.Show(ex.Message);
                lb_hata.ForeColor = Color.Red;
                lb_hata.Text = ex.Message;

            }
        }

        private void btn_clr_Click(object sender, EventArgs e)
        {
            chk_liste.Items.Clear();
        }

        private void btn_sil2_Click(object sender, EventArgs e)
        {
            chk_liste.Items.Remove(txt_input.Text);
            txt_input.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            chk_liste.Items.Clear();
            for(int i=0;i<15;i++)
            {
                chk_liste.Items.Add((i+1).ToString() + ". Eleman");

            }
        }

        private void btn_all_Click(object sender, EventArgs e)
        {
            for(int i=0; i < chk_liste.Items.Count; i++)
            {
                chk_liste.SetItemChecked(i, true);
            }
        }

        private void btn_kaldir_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chk_liste.Items.Count; i++)
            {   
                chk_liste.SetItemChecked(i, false);
            }

           /* for (int i=((chk_liste.Items.Count)-1);i>=0;i--)  //boyut aralıkları önemli
            {
                chk_liste.SetItemChecked(i,false);  
            }*///silmek için for tersten gezer
        }

        private void btn_ters_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chk_liste.Items.Count; i++)
            {
                if(chk_liste.GetItemChecked(i)==true)  //seti varsa get de vardır!
                {
                    chk_liste.SetItemChecked(i,false);
                }
                else
                {
                    chk_liste.SetItemChecked(i, true);
                }                
            }
        }

        private void tümünüSeçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chk_liste.Items.Count; i++)
            {
                chk_liste.SetItemChecked(i, true);
            }
        }

        private void seçimiKaldırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chk_liste.Items.Count; i++)
            {
                chk_liste.SetItemChecked(i, false);
            }
        }

        private void tersiniSeçToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < chk_liste.Items.Count; i++)
            {
                if (chk_liste.GetItemChecked(i) == true)  //seti varsa get de vardır!
                {
                    chk_liste.SetItemChecked(i, false);
                }
                else
                {
                    chk_liste.SetItemChecked(i, true);
                } 
            }
        }

        private void button_delete_Click(object sender, EventArgs e)
        {
            for(int i=chk_liste.CheckedIndices.Count-1;i>=0;i--)  //hatalı for(int i=((chk_liste.Items.Count)-1); i>=0; i--)   tüm indisler değil, seçililer arasından
            {
                int selectedindices = chk_liste.CheckedIndices[i];
                chk_liste.Items.RemoveAt(selectedindices);
            }
        }
    }
}
