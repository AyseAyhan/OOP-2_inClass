﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections; //array list için
using System.Net.NetworkInformation;

namespace _6._3
{
    //ARRAY LIST
    //LİSTVİEW da viewi details işaretle, üstündeki küçük oktan
    //derste sadece textbox kullanıldı ben label+text kullandığım için biraz farklı
    //güncelleme labela bağlı, derste textboxta görünüyor tıklanılan kişi bilgisi
    public partial class Form1 : Form
    {
        ArrayList myArrayList;
        public Form1()
        {
            InitializeComponent();
        }      
     

        private void listogr_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            lbID.Text = listogr.Items[listogr.FocusedItem.Index].SubItems[3].Text;
            lbAd.Text = listogr.Items[listogr.FocusedItem.Index].SubItems[0].Text;
            lbSoyad.Text = listogr.Items[listogr.FocusedItem.Index].SubItems[1].Text;
            lbYas.Text = listogr.Items[listogr.FocusedItem.Index].SubItems[2].Text;
        }
        private void listele()
        {
            listogr.Items.Clear();
            //bu olmazsa tüm listeyi tekrar döndürür
            for (int i = 0; i < myArrayList.Count; i++)
            {
                Ogrenci tmpOgrenci = (Ogrenci)myArrayList[i];
                //typecasting yapılmazsa yazdırılamaz, ogrenci tipinde
                string[] row = { tmpOgrenci.OgrAd, tmpOgrenci.OgrSoyad, tmpOgrenci.OgrYas.ToString(), tmpOgrenci.OgrId.ToString() };
                ListViewItem item = new ListViewItem(row);
                listogr.Items.Add(item);

            }

        }
        private void Form1_Load_1(object sender, EventArgs e)
        {
            myArrayList = new ArrayList();
            /*  myArrayList.Add("string value");
              myArrayList.Add(33);
              myArrayList.Add(33.2);
              //
              //farklı veri tipleri diziye eklenebilir, tipi kontrol edecek olan programı yazan
            */
            myArrayList.Add(new Ogrenci("Ayşe", "Ayhan", 21, 1058));
            myArrayList.Add(new Ogrenci("Hermes", "Three Times Great", 100, 19));
            myArrayList.Add(new Ogrenci("Carl", "Jung", 79, 11));
          
            listele();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
                for (int i = 0; i < myArrayList.Count; i++)
                {
                    Ogrenci tmpOgr = (Ogrenci)myArrayList[i];
                    if (tmpOgr.OgrId.ToString() == lbID.Text)
                    {
                    try
                    {
                        if (txt_name.Text != " ")
                        {
                            ((Ogrenci)myArrayList[i]).OgrAd = txt_name.Text;
                        }

                        if (txt_soyad.Text != " ")
                        {
                            ((Ogrenci)myArrayList[i]).OgrSoyad = txt_soyad.Text;
                        }
                        else
                        {
                            continue;
                        }


                        if (txt_age.Text != " ")
                        {
                            ((Ogrenci)myArrayList[i]).OgrYas = int.Parse(txt_age.Text);
                        }
                    }
                    catch(Exception)
                    {

                    }

                    }
                }
            listele();
        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            myArrayList.Add(new Ogrenci(txt_name.Text, txt_soyad.Text, int.Parse(txt_age.Text), int.Parse(txt_id.Text)));
            listele();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < myArrayList.Count; i++)
            {
                Ogrenci tmpOgr = (Ogrenci)myArrayList[i];
                if (tmpOgr.OgrId.ToString() == lbID.Text)
                {
                    myArrayList.RemoveAt(i);
                }
            }
            listele();
        }
    }
       
}
