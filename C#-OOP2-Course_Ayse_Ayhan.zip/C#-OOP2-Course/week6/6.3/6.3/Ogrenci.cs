﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6._3
{
    internal class Ogrenci
    {
        private int ogrYas;
        private string ogrAd;
        private string ogrSoyad;
        private int ogrId;

        public string OgrAd
        {
            get { return ogrAd; }
            set { ogrAd = value; }
        }
        public string OgrSoyad
        {
            get { return ogrSoyad; }
            set { ogrSoyad = value; }
        }
        public int OgrYas
        {
            get { return ogrYas; }
            set { ogrYas = value; }
        }
        public int OgrId
        {
            get { return ogrId; }
            set { ogrId = value; }
        }

        public Ogrenci(string ogrAd, string ogrSoyad, int ogrYas, int ogrID)
        {
            this.ogrAd = ogrAd;
            this.ogrSoyad = ogrSoyad;
            this.ogrYas = ogrYas;
            this.ogrId = ogrID;
        }
    }
}