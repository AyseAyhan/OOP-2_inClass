﻿namespace _6._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listogr = new System.Windows.Forms.ListView();
            this.c1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.c2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.c3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.c4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lbID = new System.Windows.Forms.Label();
            this.lbAd = new System.Windows.Forms.Label();
            this.lbSoyad = new System.Windows.Forms.Label();
            this.lbYas = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.txt_age = new System.Windows.Forms.TextBox();
            this.txt_soyad = new System.Windows.Forms.TextBox();
            this.txt_id = new System.Windows.Forms.TextBox();
            this.txt_name = new System.Windows.Forms.TextBox();
            this.btn_ekle = new System.Windows.Forms.Button();
            this.btnsil = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listogr
            // 
            this.listogr.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.c1,
            this.c2,
            this.c3,
            this.c4});
            this.listogr.GridLines = true;
            this.listogr.HideSelection = false;
            this.listogr.Location = new System.Drawing.Point(28, 47);
            this.listogr.Name = "listogr";
            this.listogr.Size = new System.Drawing.Size(439, 315);
            this.listogr.TabIndex = 0;
            this.listogr.UseCompatibleStateImageBehavior = false;
            this.listogr.View = System.Windows.Forms.View.Details;
            this.listogr.SelectedIndexChanged += new System.EventHandler(this.listogr_SelectedIndexChanged_1);
            // 
            // c1
            // 
            this.c1.Text = "İSİM";
            this.c1.Width = 80;
            // 
            // c2
            // 
            this.c2.Text = "SOYİSİM";
            this.c2.Width = 80;
            // 
            // c3
            // 
            this.c3.Text = "YAŞ";
            this.c3.Width = 80;
            // 
            // c4
            // 
            this.c4.Text = "ID";
            this.c4.Width = 80;
            // 
            // lbID
            // 
            this.lbID.AutoSize = true;
            this.lbID.Location = new System.Drawing.Point(484, 97);
            this.lbID.Name = "lbID";
            this.lbID.Size = new System.Drawing.Size(18, 13);
            this.lbID.TabIndex = 1;
            this.lbID.Text = "ID";
            // 
            // lbAd
            // 
            this.lbAd.AutoSize = true;
            this.lbAd.Location = new System.Drawing.Point(484, 143);
            this.lbAd.Name = "lbAd";
            this.lbAd.Size = new System.Drawing.Size(20, 13);
            this.lbAd.TabIndex = 2;
            this.lbAd.Text = "Ad";
            // 
            // lbSoyad
            // 
            this.lbSoyad.AutoSize = true;
            this.lbSoyad.Location = new System.Drawing.Point(484, 189);
            this.lbSoyad.Name = "lbSoyad";
            this.lbSoyad.Size = new System.Drawing.Size(37, 13);
            this.lbSoyad.TabIndex = 3;
            this.lbSoyad.Text = "Soyad";
            // 
            // lbYas
            // 
            this.lbYas.AutoSize = true;
            this.lbYas.Location = new System.Drawing.Point(484, 235);
            this.lbYas.Name = "lbYas";
            this.lbYas.Size = new System.Drawing.Size(25, 13);
            this.lbYas.TabIndex = 4;
            this.lbYas.Text = "Yaş";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(487, 278);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 5;
            this.button1.Text = "Güncelle";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_age
            // 
            this.txt_age.Location = new System.Drawing.Point(645, 235);
            this.txt_age.Name = "txt_age";
            this.txt_age.Size = new System.Drawing.Size(100, 20);
            this.txt_age.TabIndex = 6;
            // 
            // txt_soyad
            // 
            this.txt_soyad.Location = new System.Drawing.Point(645, 189);
            this.txt_soyad.Name = "txt_soyad";
            this.txt_soyad.Size = new System.Drawing.Size(100, 20);
            this.txt_soyad.TabIndex = 7;
            // 
            // txt_id
            // 
            this.txt_id.Location = new System.Drawing.Point(645, 97);
            this.txt_id.Name = "txt_id";
            this.txt_id.Size = new System.Drawing.Size(100, 20);
            this.txt_id.TabIndex = 8;
            // 
            // txt_name
            // 
            this.txt_name.Location = new System.Drawing.Point(645, 143);
            this.txt_name.Name = "txt_name";
            this.txt_name.Size = new System.Drawing.Size(100, 20);
            this.txt_name.TabIndex = 9;
            // 
            // btn_ekle
            // 
            this.btn_ekle.Location = new System.Drawing.Point(600, 278);
            this.btn_ekle.Name = "btn_ekle";
            this.btn_ekle.Size = new System.Drawing.Size(75, 23);
            this.btn_ekle.TabIndex = 10;
            this.btn_ekle.Text = "Ekle";
            this.btn_ekle.UseVisualStyleBackColor = true;
            this.btn_ekle.Click += new System.EventHandler(this.btn_ekle_Click);
            // 
            // btnsil
            // 
            this.btnsil.Location = new System.Drawing.Point(713, 278);
            this.btnsil.Name = "btnsil";
            this.btnsil.Size = new System.Drawing.Size(75, 23);
            this.btnsil.TabIndex = 11;
            this.btnsil.Text = "Sil";
            this.btnsil.UseVisualStyleBackColor = true;
            this.btnsil.Click += new System.EventHandler(this.btnsil_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnsil);
            this.Controls.Add(this.btn_ekle);
            this.Controls.Add(this.txt_name);
            this.Controls.Add(this.txt_id);
            this.Controls.Add(this.txt_soyad);
            this.Controls.Add(this.txt_age);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbYas);
            this.Controls.Add(this.lbSoyad);
            this.Controls.Add(this.lbAd);
            this.Controls.Add(this.lbID);
            this.Controls.Add(this.listogr);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load_1);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listogr;
        private System.Windows.Forms.ColumnHeader c1;
        private System.Windows.Forms.ColumnHeader c2;
        private System.Windows.Forms.ColumnHeader c3;
        private System.Windows.Forms.ColumnHeader c4;
        private System.Windows.Forms.Label lbID;
        private System.Windows.Forms.Label lbAd;
        private System.Windows.Forms.Label lbSoyad;
        private System.Windows.Forms.Label lbYas;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txt_age;
        private System.Windows.Forms.TextBox txt_soyad;
        private System.Windows.Forms.TextBox txt_id;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Button btn_ekle;
        private System.Windows.Forms.Button btnsil;
    }
}

