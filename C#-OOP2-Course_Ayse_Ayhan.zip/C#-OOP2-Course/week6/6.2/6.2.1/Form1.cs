﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO; //Dosya işlemleri

namespace _6._2._1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFile= new SaveFileDialog();
            saveFile.InitialDirectory = @"c:\";
            saveFile.Title = "Dosyayı Kaydet";
            saveFile.DefaultExt = "txt";
            //saveFile.Filter = "txt Dosyalari|*.txt|Tüm Dosyalar *.*";
            saveFile.Filter="Metin dosyaları|*.txt|Tüm dosyalar|*.*";
            //uzantı yanlış verilse bile bu formatla açılır

            if (saveFile.ShowDialog()==DialogResult.OK)
            {
                lb_dosya.Text = saveFile.FileName;
                StreamWriter Kayit=new StreamWriter(saveFile.FileName);
                Kayit.WriteLine("Bu birinci dosya");
                Kayit.Close();
            }
        }
    }
}
