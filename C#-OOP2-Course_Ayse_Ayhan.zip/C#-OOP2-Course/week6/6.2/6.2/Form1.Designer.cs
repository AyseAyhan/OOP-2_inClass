﻿namespace _6._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_openfile = new System.Windows.Forms.Button();
            this.listBox_file = new System.Windows.Forms.ListBox();
            this.listBox_name = new System.Windows.Forms.ListBox();
            this.pb_resim = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pb_resim)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_openfile
            // 
            this.btn_openfile.Location = new System.Drawing.Point(12, 23);
            this.btn_openfile.Name = "btn_openfile";
            this.btn_openfile.Size = new System.Drawing.Size(114, 47);
            this.btn_openfile.TabIndex = 0;
            this.btn_openfile.Text = "Dosya Aç";
            this.btn_openfile.UseVisualStyleBackColor = true;
            this.btn_openfile.Click += new System.EventHandler(this.btn_openfile_Click);
            // 
            // listBox_file
            // 
            this.listBox_file.FormattingEnabled = true;
            this.listBox_file.Location = new System.Drawing.Point(12, 76);
            this.listBox_file.Name = "listBox_file";
            this.listBox_file.Size = new System.Drawing.Size(387, 108);
            this.listBox_file.TabIndex = 1;
            this.listBox_file.SelectedIndexChanged += new System.EventHandler(this.listBox_file_SelectedIndexChanged);
            // 
            // listBox_name
            // 
            this.listBox_name.FormattingEnabled = true;
            this.listBox_name.Location = new System.Drawing.Point(12, 200);
            this.listBox_name.Name = "listBox_name";
            this.listBox_name.Size = new System.Drawing.Size(230, 238);
            this.listBox_name.TabIndex = 2;
            // 
            // pb_resim
            // 
            this.pb_resim.Location = new System.Drawing.Point(405, 23);
            this.pb_resim.Name = "pb_resim";
            this.pb_resim.Size = new System.Drawing.Size(366, 415);
            this.pb_resim.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pb_resim.TabIndex = 3;
            this.pb_resim.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pb_resim);
            this.Controls.Add(this.listBox_name);
            this.Controls.Add(this.listBox_file);
            this.Controls.Add(this.btn_openfile);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pb_resim)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btn_openfile;
        private System.Windows.Forms.ListBox listBox_file;
        private System.Windows.Forms.ListBox listBox_name;
        private System.Windows.Forms.PictureBox pb_resim;
    }
}

