﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _6._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_openfile_Click(object sender, EventArgs e)
        {
            OpenFileDialog file = new OpenFileDialog();
            file.Filter = "Resim Dosyaları |*.jpeg|Resim Dosyaları|*.bmp";
            file.InitialDirectory = @"c:\";
            file.Title = "Lütfen resim dosyalarını seçiniz.";
           
            //openfiledialog toolboxtan da set edilebilir
            file.RestoreDirectory = true;
            file.Multiselect = true;

            if (file.ShowDialog()==DialogResult.OK)
            {
                string[] DosyaYollari = file.FileNames;
                String[] DosyaAdlari = file.SafeFileNames;

                for(int i=0;i<DosyaYollari.Length;i++)
                {
                    listBox_file.Items.Add(DosyaYollari[i]);  //dosya yolunu listboxa ekleme
                    listBox_name.Items.Add(DosyaAdlari[i]);
                }
            }
        }

        private void listBox_file_SelectedIndexChanged(object sender, EventArgs e)
        {
            using (Image image = Image.FromFile(listBox_file.SelectedItem.ToString()))
            {
                pb_resim.Image = new Bitmap(image);
            }
        }

    }
}
