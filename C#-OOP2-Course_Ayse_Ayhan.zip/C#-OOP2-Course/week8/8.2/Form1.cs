﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8._1._2
{
//stockcard
//CUSTOM COMPONENT YARATMA,
//devexpress gibi sitelerde 1000$, kendine özgü, gelişmiş, çok işlevli componentler
//add project-library.net ten stockkart componenti yarattım
//tek bir component temel kodu üzerinden tüm aynı componentler için değişim yapılabiliyor
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //stockardın kendi fonksiyonları hazır
            stockKard1.SetMyStockCardValues("Kalem", 233, false);
            stockKard2.SetMyStockCardValues("PC", 333, true);
        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            //runtime zamanında oluşturma
            StockCard.StockKard stockKard = new StockCard.StockKard();
            stockKard.Name = "stk_1";
            stockKard.Location = new Point(15, 30);
            stockKard.SetMyStockCardValues("Dron", 18, true);
            this.Controls.Add(stockKard);
        }
    }
}
