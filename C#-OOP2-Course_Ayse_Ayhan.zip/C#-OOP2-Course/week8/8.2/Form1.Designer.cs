﻿namespace _8._1._2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.stockKard1 = new StockCard.StockKard();
            this.stockKard2 = new StockCard.StockKard();
            this.btn_ekle = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // stockKard1
            // 
            this.stockKard1.Location = new System.Drawing.Point(280, 53);
            this.stockKard1.Name = "stockKard1";
            this.stockKard1.Size = new System.Drawing.Size(241, 308);
            this.stockKard1.TabIndex = 0;
            // 
            // stockKard2
            // 
            this.stockKard2.Location = new System.Drawing.Point(536, 53);
            this.stockKard2.Name = "stockKard2";
            this.stockKard2.Size = new System.Drawing.Size(238, 308);
            this.stockKard2.TabIndex = 1;
            // 
            // btn_ekle
            // 
            this.btn_ekle.Location = new System.Drawing.Point(12, 389);
            this.btn_ekle.Name = "btn_ekle";
            this.btn_ekle.Size = new System.Drawing.Size(102, 35);
            this.btn_ekle.TabIndex = 2;
            this.btn_ekle.Text = "Ekle";
            this.btn_ekle.UseVisualStyleBackColor = true;
            this.btn_ekle.Click += new System.EventHandler(this.btn_ekle_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 450);
            this.Controls.Add(this.btn_ekle);
            this.Controls.Add(this.stockKard2);
            this.Controls.Add(this.stockKard1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private StockCard.StockKard stockKard1;
        private StockCard.StockKard stockKard2;
        private System.Windows.Forms.Button btn_ekle;
    }
}

