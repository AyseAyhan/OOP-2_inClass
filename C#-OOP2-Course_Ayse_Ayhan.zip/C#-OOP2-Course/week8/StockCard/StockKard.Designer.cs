﻿namespace StockCard
{
    partial class StockKard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txt_ad = new System.Windows.Forms.TextBox();
            this.txt_stokMiktar = new System.Windows.Forms.TextBox();
            this.cb1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_ad
            // 
            this.txt_ad.Location = new System.Drawing.Point(51, 57);
            this.txt_ad.Name = "txt_ad";
            this.txt_ad.Size = new System.Drawing.Size(142, 20);
            this.txt_ad.TabIndex = 0;
            // 
            // txt_stokMiktar
            // 
            this.txt_stokMiktar.Location = new System.Drawing.Point(51, 106);
            this.txt_stokMiktar.Name = "txt_stokMiktar";
            this.txt_stokMiktar.Size = new System.Drawing.Size(142, 20);
            this.txt_stokMiktar.TabIndex = 1;
            // 
            // cb1
            // 
            this.cb1.AutoSize = true;
            this.cb1.Location = new System.Drawing.Point(82, 161);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(92, 17);
            this.cb1.TabIndex = 2;
            this.cb1.Text = "Stok Tutulsun";
            this.cb1.UseVisualStyleBackColor = true;
            this.cb1.CheckedChanged += new System.EventHandler(this.cb1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(51, 221);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(142, 56);
            this.button1.TabIndex = 3;
            this.button1.Text = "İŞLEM";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // bindingSource1
            // 
            this.bindingSource1.CurrentChanged += new System.EventHandler(this.bindingSource1_CurrentChanged);
            // 
            // StockKard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cb1);
            this.Controls.Add(this.txt_stokMiktar);
            this.Controls.Add(this.txt_ad);
            this.Name = "StockKard";
            this.Size = new System.Drawing.Size(243, 316);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.TextBox txt_ad;
        private System.Windows.Forms.TextBox txt_stokMiktar;
        private System.Windows.Forms.CheckBox cb1;
        private System.Windows.Forms.Button button1;
    }
}
