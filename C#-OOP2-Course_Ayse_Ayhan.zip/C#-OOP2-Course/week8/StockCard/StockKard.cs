﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace StockCard
{
    public partial class StockKard : UserControl
    {
        public StockKard()
        {
            InitializeComponent();
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {

        }


        public void SetMyStockCardValues(String StokAd, Double StokMiktar, Boolean StokTutulsun)
        {
            txt_ad.Text = StokAd;
            txt_stokMiktar.Text = StokMiktar.ToString();
            if (StokTutulsun)
            {
                cb1.Checked = true;
                this.BackColor=Color.GreenYellow;
            }
            else
            {
                cb1.Checked = false;
                this.BackColor = Color.DarkSalmon;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("İşlem yapıldı");
        }

        private void cb1_CheckedChanged(object sender, EventArgs e)
        {
            if(cb1.Checked)
            {
                this.BackColor = Color.Goldenrod;
            }
            else
            {
                this.BackColor = Color.RosyBrown;
            }
        }
    }
}
