﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8._1
{
    //tabview
    //propertiesten tabpages-sayfa ayarları
    //tabpages collection
    //tabcontrol, her sayfa ayrıdır
    //dezavantajı bütün kodların aynı yere yığılması
    //allignment properti ile tabların yeri değiştirilebilir
    //collectiona index ile ulaşılır
    public partial class Form1 : Form
    {
        int secili_index = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btn_geri_Click(object sender, EventArgs e)
        {
            if(secili_index>=1) { secili_index--; }
            tabControl1.SelectedIndex = secili_index;
        }

        private void btn_ileri_Click(object sender, EventArgs e)
        {
            if (secili_index <= 3) { secili_index++; }
            tabControl1.SelectedIndex = secili_index;
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(tabControl1.SelectedIndex == 0)
            {
                //belirli bir formu doldur
            }
        }
    }
}
