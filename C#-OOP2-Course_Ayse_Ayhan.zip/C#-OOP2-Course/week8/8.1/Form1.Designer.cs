﻿namespace _8._1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.page1 = new System.Windows.Forms.TabPage();
            this.button1 = new System.Windows.Forms.Button();
            this.page2 = new System.Windows.Forms.TabPage();
            this.page3 = new System.Windows.Forms.TabPage();
            this.page4 = new System.Windows.Forms.TabPage();
            this.page5 = new System.Windows.Forms.TabPage();
            this.btn_ileri = new System.Windows.Forms.Button();
            this.btn_geri = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.tabControl1.SuspendLayout();
            this.page1.SuspendLayout();
            this.page2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.tabControl1.Controls.Add(this.page1);
            this.tabControl1.Controls.Add(this.page2);
            this.tabControl1.Controls.Add(this.page3);
            this.tabControl1.Controls.Add(this.page4);
            this.tabControl1.Controls.Add(this.page5);
            this.tabControl1.Location = new System.Drawing.Point(0, 23);
            this.tabControl1.Multiline = true;
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(593, 313);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
            // 
            // page1
            // 
            this.page1.Controls.Add(this.button1);
            this.page1.Location = new System.Drawing.Point(4, 4);
            this.page1.Name = "page1";
            this.page1.Padding = new System.Windows.Forms.Padding(3);
            this.page1.Size = new System.Drawing.Size(585, 287);
            this.page1.TabIndex = 0;
            this.page1.Text = "1";
            this.page1.UseVisualStyleBackColor = true;
            this.page1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.button1.Location = new System.Drawing.Point(125, 25);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(364, 219);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // page2
            // 
            this.page2.Controls.Add(this.button2);
            this.page2.Location = new System.Drawing.Point(4, 4);
            this.page2.Name = "page2";
            this.page2.Padding = new System.Windows.Forms.Padding(3);
            this.page2.Size = new System.Drawing.Size(585, 287);
            this.page2.TabIndex = 1;
            this.page2.Text = "2";
            this.page2.UseVisualStyleBackColor = true;
            this.page2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // page3
            // 
            this.page3.Location = new System.Drawing.Point(4, 4);
            this.page3.Name = "page3";
            this.page3.Size = new System.Drawing.Size(585, 287);
            this.page3.TabIndex = 2;
            this.page3.Text = "3";
            this.page3.UseVisualStyleBackColor = true;
            // 
            // page4
            // 
            this.page4.Location = new System.Drawing.Point(4, 4);
            this.page4.Name = "page4";
            this.page4.Size = new System.Drawing.Size(585, 287);
            this.page4.TabIndex = 3;
            this.page4.Text = "4";
            this.page4.UseVisualStyleBackColor = true;
            // 
            // page5
            // 
            this.page5.Location = new System.Drawing.Point(4, 4);
            this.page5.Name = "page5";
            this.page5.Size = new System.Drawing.Size(585, 287);
            this.page5.TabIndex = 4;
            this.page5.Text = "5";
            this.page5.UseVisualStyleBackColor = true;
            // 
            // btn_ileri
            // 
            this.btn_ileri.Location = new System.Drawing.Point(444, 371);
            this.btn_ileri.Name = "btn_ileri";
            this.btn_ileri.Size = new System.Drawing.Size(83, 44);
            this.btn_ileri.TabIndex = 1;
            this.btn_ileri.Text = "İleri >>>";
            this.btn_ileri.UseVisualStyleBackColor = true;
            this.btn_ileri.Click += new System.EventHandler(this.btn_ileri_Click);
            // 
            // btn_geri
            // 
            this.btn_geri.Location = new System.Drawing.Point(98, 371);
            this.btn_geri.Name = "btn_geri";
            this.btn_geri.Size = new System.Drawing.Size(95, 44);
            this.btn_geri.TabIndex = 2;
            this.btn_geri.Text = "<<< Geri";
            this.btn_geri.UseVisualStyleBackColor = true;
            this.btn_geri.Click += new System.EventHandler(this.btn_geri_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 304);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(628, 61);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.IndianRed;
            this.button2.Location = new System.Drawing.Point(64, 32);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(450, 207);
            this.button2.TabIndex = 0;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(589, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.btn_geri);
            this.Controls.Add(this.btn_ileri);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.page1.ResumeLayout(false);
            this.page2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage page1;
        private System.Windows.Forms.TabPage page2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabPage page3;
        private System.Windows.Forms.TabPage page4;
        private System.Windows.Forms.TabPage page5;
        private System.Windows.Forms.Button btn_ileri;
        private System.Windows.Forms.Button btn_geri;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button button2;
    }
}

