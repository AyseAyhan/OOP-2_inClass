﻿namespace UserControl1
{
    partial class UserControl1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txt_stok1 = new TextBox();
            txt_stokMiktar1 = new TextBox();
            txt_stok2 = new TextBox();
            txt_stokMiktar2 = new TextBox();
            txt_stok3 = new TextBox();
            txt_stokMiktar3 = new TextBox();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // txt_stok1
            // 
            txt_stok1.Location = new Point(57, 64);
            txt_stok1.Name = "txt_stok1";
            txt_stok1.Size = new Size(100, 23);
            txt_stok1.TabIndex = 0;
            // 
            // txt_stokMiktar1
            // 
            txt_stokMiktar1.Location = new Point(57, 93);
            txt_stokMiktar1.Name = "txt_stokMiktar1";
            txt_stokMiktar1.Size = new Size(100, 23);
            txt_stokMiktar1.TabIndex = 1;
            // 
            // txt_stok2
            // 
            txt_stok2.Location = new Point(230, 64);
            txt_stok2.Name = "txt_stok2";
            txt_stok2.Size = new Size(100, 23);
            txt_stok2.TabIndex = 2;
            // 
            // txt_stokMiktar2
            // 
            txt_stokMiktar2.Location = new Point(230, 93);
            txt_stokMiktar2.Name = "txt_stokMiktar2";
            txt_stokMiktar2.Size = new Size(100, 23);
            txt_stokMiktar2.TabIndex = 3;
            // 
            // txt_stok3
            // 
            txt_stok3.Location = new Point(409, 64);
            txt_stok3.Name = "txt_stok3";
            txt_stok3.Size = new Size(100, 23);
            txt_stok3.TabIndex = 4;
            // 
            // txt_stokMiktar3
            // 
            txt_stokMiktar3.Location = new Point(409, 93);
            txt_stokMiktar3.Name = "txt_stokMiktar3";
            txt_stokMiktar3.Size = new Size(100, 23);
            txt_stokMiktar3.TabIndex = 5;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(57, 151);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(98, 19);
            checkBox1.TabIndex = 6;
            checkBox1.Text = "Stok Tutulsun";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Location = new Point(230, 151);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(98, 19);
            checkBox2.TabIndex = 7;
            checkBox2.Text = "Stok Tutulsun";
            checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Location = new Point(409, 151);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(98, 19);
            checkBox3.TabIndex = 8;
            checkBox3.Text = "Stok Tutulsun";
            checkBox3.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Location = new Point(184, 245);
            button1.Name = "button1";
            button1.Size = new Size(241, 92);
            button1.TabIndex = 9;
            button1.Text = "İŞLEM";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // UserControl1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(button1);
            Controls.Add(checkBox3);
            Controls.Add(checkBox2);
            Controls.Add(checkBox1);
            Controls.Add(txt_stokMiktar3);
            Controls.Add(txt_stok3);
            Controls.Add(txt_stokMiktar2);
            Controls.Add(txt_stok2);
            Controls.Add(txt_stokMiktar1);
            Controls.Add(txt_stok1);
            Name = "UserControl1";
            Size = new Size(800, 450);
            Load += UserControl1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txt_stok1;
        private TextBox txt_stokMiktar1;
        private TextBox txt_stok2;
        private TextBox txt_stokMiktar2;
        private TextBox txt_stok3;
        private TextBox txt_stokMiktar3;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private Button button1;
    }
}