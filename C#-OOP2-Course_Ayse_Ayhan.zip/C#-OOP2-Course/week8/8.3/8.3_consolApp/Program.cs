﻿class Program
{
    static void Main(string[] args)
    {
        int originalValue = 50;
        Console.WriteLine("Change 1 Metodundan önce: " + originalValue);  //50 dir
        ChangeMethod_1(5, 10, originalValue);
        Console.WriteLine("Change 1 Metodundan sonra: " + originalValue); //50 dir  //Original value bu scopeta 50 olduğu için başka scopeta değişse de adres olmadığı-global olmadığı için değişmez, return de yok
        Console.WriteLine("------------------");
        Console.WriteLine("");



        originalValue = 50;   //bu defa ref old. için 65 olur-adres pass edilir
        Console.WriteLine("Change 1 Metodundan önce: " + originalValue);  //50
        //ref->adres
        ChangeMethod_2(5, 10, ref originalValue);
        Console.WriteLine("Change 2 Metodundan sonra: " + originalValue);  //65
        Console.WriteLine("-------------------");
        Console.WriteLine("");

        originalValue = 50;
        Console.WriteLine("Change 3 Metodundan önce: " + originalValue);   //50
        ChangeMethod_3(5,10, out originalValue); //out keywordu iki tarafta da kullanılmalı
        Console.WriteLine("Change 3 Metodundan sonra: " + originalValue);  //80, manipüle edildi
        Console.WriteLine("-------------------");
        Console.WriteLine("");

        originalValue = 50;
        int oV2 = 50;
        Console.WriteLine("Change 4 Metodundan önce: " + originalValue);   //50
        Console.WriteLine("Change 4 Metodundan önce: " + oV2);    //50
        ChangeMethod_4(5, 10, out originalValue, out oV2); //out keywordu iki tarafta da kullanılmalı
        Console.WriteLine("Change 4 Metodundan sonra: " + originalValue); //90
        Console.WriteLine("Change 4 Metodundan sonra: " + oV2);  //30
        Console.WriteLine("-------------------");
        Console.WriteLine("");
    }

    static void ChangeMethod_1(int x, int y, int i)
    {
        i = i + x + y;
    }

    static void ChangeMethod_2(int x, int y, ref int i)
    {
        //ref ile adres pass edilir
        i = i + x + y;
    }

    //out olduğunda da ref gibi
    static void ChangeMethod_3(int x, int y, out int i)
    {
        i = 80;  //out denildiğinde i manipüle edilmek zorunda
        //altta i ile ilgili değişiklik yapılmazsa derlemez
    }

    static void ChangeMethod_4(int x, int y, out int i, out int j)
    {
        i = 90;
        j = 30;
    }

}