﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3._2_stringformatting
{
    public partial class Form1 : Form
    {
        double num;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            num=2222222.45456546 ;
            text_num1.Text=num.ToString();
        }

        private void PrintNumwithFormatting()  //parametre yok
        {
            text_print.Text ="Para:\t\t\t"+ num.ToString("c");  //"c"? para figürlü gösterim için c
            text_print.Text += Environment.NewLine + "Bilimsel:\t\t\t" + num.ToString("e");  //bilimsel gösterim için e
            //textboxın aşağı genişlemesi için multiline açılmalı
            text_print.Text += Environment.NewLine + "Fixed Point:\t\t" + num.ToString("f"); //iki haneye yuvarlar  "f"
            text_print.Text += Environment.NewLine + "General:\t\t\t" + num.ToString("g");   //genel gösterim
            text_print.Text += Environment.NewLine + "Thousand Seperator:\t" + num.ToString("n"); // "n" binlik parçalara böler
            text_print.Text += Environment.NewLine + "Custom:\t\t\t" + num.ToString("(#),##"); //tam kısmı parantezde, ondalıklı iki bsm şeklinde, #sayısı değişebilir
            text_print.Text+=Environment.NewLine+"Custom 2:\t\t\t"+num.ToString("$#$.###");  
        }

        private void button_format_Click(object sender, EventArgs e)  // t figürü geldi, yuvarlama yaptı, para figürü bilgisyarın bölgesel ayarlarından değişir
        {
            num = double.Parse(text_num1.Text);
            PrintNumwithFormatting();
        }
        //stringde alt satır = +Environment.NewLine
    }
}
