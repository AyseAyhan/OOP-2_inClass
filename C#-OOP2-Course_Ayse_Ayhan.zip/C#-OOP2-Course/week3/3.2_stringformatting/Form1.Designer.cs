﻿namespace _3._2_stringformatting
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.text_num1 = new System.Windows.Forms.TextBox();
            this.text_print = new System.Windows.Forms.TextBox();
            this.button_format = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // text_num1
            // 
            this.text_num1.Location = new System.Drawing.Point(21, 37);
            this.text_num1.Name = "text_num1";
            this.text_num1.Size = new System.Drawing.Size(100, 20);
            this.text_num1.TabIndex = 0;
            this.text_num1.Text = "number 1";
            // 
            // text_print
            // 
            this.text_print.Location = new System.Drawing.Point(127, 118);
            this.text_print.Multiline = true;
            this.text_print.Name = "text_print";
            this.text_print.Size = new System.Drawing.Size(527, 200);
            this.text_print.TabIndex = 2;
            // 
            // button_format
            // 
            this.button_format.Location = new System.Drawing.Point(127, 12);
            this.button_format.Name = "button_format";
            this.button_format.Size = new System.Drawing.Size(128, 57);
            this.button_format.TabIndex = 3;
            this.button_format.Text = "Format";
            this.button_format.UseVisualStyleBackColor = true;
            this.button_format.Click += new System.EventHandler(this.button_format_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_format);
            this.Controls.Add(this.text_print);
            this.Controls.Add(this.text_num1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox text_num1;
        private System.Windows.Forms.TextBox text_print;
        private System.Windows.Forms.Button button_format;
    }
}

