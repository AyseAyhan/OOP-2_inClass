﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _3._1;  //dll ile bağlantı

//dll ne amaçla kullanılır? nasıl bağlanır?

namespace _3._1.web
{
    //DLL EKLEME: References, add reference, -browse ya da proje dosyasına gelip open in folder- ilgili .dll'i seç.
    //Classları, dosyaları, formun içini tek tek görebileceksin
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Calculate calc; //dll deki calculate classı için obje
        private void Form1_Load(object sender, EventArgs e)
        {
           
           
        }
        private void button1_Click(object sender, EventArgs e)
        {
            _3._1.Calculate calc = new _3._1.Calculate(); //dll deki calculate classı için obje
                    // dll namespace'i.dll class'ı obje= new dll namespace.dll class();
            label_sign.Text = "+";
            int result = calc.Add(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text));
            label_result.Text = result.ToString();

            /* int num1 = Convert.ToInt32(textBox1.Text);
             int num2 = Convert.ToInt32(textBox2.Text);
             label_result.Text = (num1 + num2).ToString(); */
        }

        private void button2_Click(object sender, EventArgs e)
        {
            _3._1.Calculate calc = new _3._1.Calculate();
            label_sign.Text = "-";
            int result1 = calc.Substract(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text));
            label_result.Text = result1.ToString();


            /*  int num1 = int.Parse(textBox1.Text);
             int num2 = int.Parse(textBox2.Text);  */

            // label_result.Text = (num1 - num2).ToString();   

        }

        private void button_sum2_Click(object sender, EventArgs e)
        {
            _3._1.Calculate calc = new _3._1.Calculate();
            label_sign.Text = "+";
            string result = calc.Add2(Convert.ToInt32(textBox1.Text), Convert.ToInt32(textBox2.Text));
            label_result.Text = result;
            //yazım şeklinin a+b=xxx ya da a ile b toplamı=xxx gibi değişmesi için dll in değişmesi, rebuild edilmesi yeterli
            //dllin başka biriyle paylaşımı için properties-copylocal true olmalı

        }
    }

}
