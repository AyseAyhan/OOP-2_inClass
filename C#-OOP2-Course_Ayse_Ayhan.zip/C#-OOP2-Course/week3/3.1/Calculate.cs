﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _3._1
{
    //dll'ler !!! Class Library (.NET framework) dll, dll'i eklemek, pathi kopyala
    //.NET windows forms uygulaması .exe uzantılıdır (windowspapp.exe)
    //solution dosyası, properties otomatik proje oluşturur, sol dosyası rebuild
    public class Calculate
    {
        public int Add(int a,int b)
        { return a + b; }
        public int Substract(int a,int b)
        { return a - b; }

        public string Add2(int a, int b)
        {
            return a+" + "+b+" = "+(a+b);
        }

    }

}
