﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _3._2
{
    //exception handling
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button_div_Click(object sender, EventArgs e)
        {

           /* double result= Convert.ToDouble(textBox1.Text)/Convert.ToInt32(textBox2.Text);
            label_result.Text=result.ToString();   */
           try
            { 
               double result=double.Parse(textBox1.Text)/double.Parse(textBox2.Text);  //texte girdi yapılmazsa hata verir
               label_result.Text = result.ToString();
                //durum2
                //durum3
                //.... try bütün sıraları yapmaya çalışır
            } 

            //catch(OverflowException)  //overflow hatası olursa
            //{

            //    label_result.Text = "There is an error!";
            //}

            catch (Exception ex)
            {

                label_result.Text=ex.ToString(); //hatayı yakalar, yazdırır  hata konumunu da gösterebilir

                textBox1.Text = "0";
                textBox2.Text = "0";
                textBox1.BackColor = Color.Red;
                textBox2.BackColor = Color.Red;
            }

        }
    }
}
