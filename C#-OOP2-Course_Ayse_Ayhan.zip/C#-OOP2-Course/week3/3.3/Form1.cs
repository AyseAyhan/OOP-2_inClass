﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace _3._3
{
    //DateTime, tarih, zaman vs. çekme
    //Time formatting
    //herhangi bir componente çift tıklayınca koduna götürür
    public partial class Form1 : Form
    {
        DateTime simdi;  //form classının içinde tanımlanır
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            simdi=DateTime.Now;
            //text_date.Text = simdi.ToString();
            //datetimepicker componenti forma eklenirse tarihi gösterir
        }
      private void button_format_Click(object sender, EventArgs e)
        {
            PrintwithFormatting(); //butona tıklandığında parametresiz format fonksiyonu çağırılır
        }  
        private void PrintwithFormatting() //fonksiyon önemli
        {
            /* ÖNEMLİ:!!! Keywordler önemli, sınavda çıkabilir. Hangi durum için hangi keyword "c" "e" "d" "D" "t" "T" "g" "f" vs. */
            text_print.Text = "Short Date:\t" + simdi.ToString("d") + Environment.NewLine;
            text_print.Text+="Long Date:\t"+simdi.ToString("D")+Environment.NewLine;  //bölge ayarları-tarih, harf yerine boşluk olursa saati alır
            text_print.Text += "Short Time:\t" + simdi.ToString("t") + Environment.NewLine;
            text_print.Text += "Long Time:\t" + simdi.ToString("T") + Environment.NewLine;
            text_print.Text += "Short Date Time:\t" + simdi.ToString("g") + Environment.NewLine;  //+= olmazsa üzerine yazar, son yazılan kalır
            text_print.Text += "Long Date Time:\t" + simdi.ToString("f") + Environment.NewLine;
            text_print.Text += "Custom 1:\t\t" + simdi.ToString("MM.dd.yyyy") + Environment.NewLine;
            text_print.Text += "Custom 2:\t\t" + simdi.ToString("dd.MM.yyyy") + Environment.NewLine;
            text_print.Text += "Custom random:\t" + simdi.ToString("yyyy dd.MM.yyyy") + Environment.NewLine;  //fromat çok farklı ayarlanabilir
            text_print.Text += "Custom Day:\t" + simdi.ToString("dddd dd.MM.yyyy") + Environment.NewLine;
            text_print.Text += "Custom Day 2:\t" + simdi.ToString("dd.MM.yyyy dddd") + Environment.NewLine;
            text_print.Text += "Custom Month:\t" + simdi.ToString("MMM dd.MM.yyyy") + Environment.NewLine; //örn ayı yazıyla yazması için .03 yerine Mart
            text_print.Text += "Custom Year:\t" + simdi.ToString("yyyy dd.MM.yyyy") + Environment.NewLine;
            text_print.Text += "Custom All:\t" + simdi.ToString("dddd dd MMMM yyyy  HH:mm:ss") + Environment.NewLine;

        }

        private void dtp_zaman_ValueChanged(object sender, EventArgs e)
        {
            simdi=dtp_zaman.Value;   // fonksiyon çağırılınca, dtp_zamandan seçilen zamana göre tüm formatlamaları yaptı
            PrintwithFormatting();

            //DatetTimePicker>>properties>>formattan tarih formatı değiştirilebilir
            //calender figürününün gitmesi için prop>>showupdown-true

        }

        private void button_day_Click(object sender, EventArgs e)
        {
            simdi = dtp_zaman.Value.AddDays(1); //datetimepickername.value=tarihi almak için   dtp.value.AddDays()  gün eklemek için, -1 önceki gün 2 iki sonraki gün
          
            PrintwithFormatting() ;
        }

        private void button_day2_Click(object sender, EventArgs e)
        {
            simdi = dtp_zaman.Value.AddDays(-1);
            PrintwithFormatting() ;
        }
    }
}
