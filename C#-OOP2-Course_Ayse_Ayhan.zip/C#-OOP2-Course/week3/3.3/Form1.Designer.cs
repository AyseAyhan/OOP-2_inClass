﻿namespace _3._3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.text_date = new System.Windows.Forms.TextBox();
            this.text_print = new System.Windows.Forms.TextBox();
            this.button_format = new System.Windows.Forms.Button();
            this.dtp_zaman = new System.Windows.Forms.DateTimePicker();
            this.button_day = new System.Windows.Forms.Button();
            this.button_day2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // text_date
            // 
            this.text_date.Location = new System.Drawing.Point(12, 37);
            this.text_date.Multiline = true;
            this.text_date.Name = "text_date";
            this.text_date.Size = new System.Drawing.Size(149, 30);
            this.text_date.TabIndex = 0;
            // 
            // text_print
            // 
            this.text_print.Location = new System.Drawing.Point(232, 147);
            this.text_print.Multiline = true;
            this.text_print.Name = "text_print";
            this.text_print.Size = new System.Drawing.Size(420, 291);
            this.text_print.TabIndex = 1;
            // 
            // button_format
            // 
            this.button_format.Location = new System.Drawing.Point(232, 26);
            this.button_format.Name = "button_format";
            this.button_format.Size = new System.Drawing.Size(162, 59);
            this.button_format.TabIndex = 2;
            this.button_format.Text = "Format Date";
            this.button_format.UseVisualStyleBackColor = true;
            this.button_format.Click += new System.EventHandler(this.button_format_Click);
            // 
            // dtp_zaman
            // 
            this.dtp_zaman.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtp_zaman.Location = new System.Drawing.Point(15, 82);
            this.dtp_zaman.Name = "dtp_zaman";
            this.dtp_zaman.ShowUpDown = true;
            this.dtp_zaman.Size = new System.Drawing.Size(145, 20);
            this.dtp_zaman.TabIndex = 3;
            this.dtp_zaman.ValueChanged += new System.EventHandler(this.dtp_zaman_ValueChanged);
            // 
            // button_day
            // 
            this.button_day.Location = new System.Drawing.Point(428, 26);
            this.button_day.Name = "button_day";
            this.button_day.Size = new System.Drawing.Size(95, 41);
            this.button_day.TabIndex = 4;
            this.button_day.Text = "Add Day";
            this.button_day.UseVisualStyleBackColor = true;
            this.button_day.Click += new System.EventHandler(this.button_day_Click);
            // 
            // button_day2
            // 
            this.button_day2.Location = new System.Drawing.Point(428, 82);
            this.button_day2.Name = "button_day2";
            this.button_day2.Size = new System.Drawing.Size(95, 41);
            this.button_day2.TabIndex = 5;
            this.button_day2.Text = "Sub Day";
            this.button_day2.UseVisualStyleBackColor = true;
            this.button_day2.Click += new System.EventHandler(this.button_day2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button_day2);
            this.Controls.Add(this.button_day);
            this.Controls.Add(this.dtp_zaman);
            this.Controls.Add(this.button_format);
            this.Controls.Add(this.text_print);
            this.Controls.Add(this.text_date);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox text_date;
        private System.Windows.Forms.TextBox text_print;
        private System.Windows.Forms.Button button_format;
        private System.Windows.Forms.DateTimePicker dtp_zaman;
        private System.Windows.Forms.Button button_day;
        private System.Windows.Forms.Button button_day2;
    }
}

