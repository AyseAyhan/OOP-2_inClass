namespace _1._2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)  //butona clicklendi�inde
        {
            label1.Text = "Merhaba D�nya!";


            //her bir objenin ismi �zel/farkl� olmal�, �rn buton, buton1
            //�al��ma zaman� pre-runtime: �al��t�rmadan �nce d�zenleme tasar�m vs.   
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)   //form i�in event , mouse her hareket etti�inde, mousemove eventi
        {
            label2.Text = "Formda Hareket:\n" + "(X,Y)= " + e.X + ", " + e.Y;
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            label3.Text = "Butonda Hareket:\n (X,Y)= " + e.X + ", " + e.Y;
        }

        private void button1_MouseHover(object sender, EventArgs e)
        {
            label4.Text = "Mouse �zerinde.";  //mouse, componentin �zerinde mi de�il mi diye bakmak i�in
            label4.BackColor = Color.DarkBlue;
        }

        private void button1_MouseLeave(object sender, EventArgs e)
        {
            label4.Text = "Mouse �zerinde de�il.";
            label4.BackColor = Color.Red;
        }

        private void label4_Click(object sender, EventArgs e)
        {
            // label4.BackColor = Color.Red;
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            button2.BackColor = Color.Azure;    //double click?
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void button5_Click(object sender, EventArgs e)
        {
        }
    }
}