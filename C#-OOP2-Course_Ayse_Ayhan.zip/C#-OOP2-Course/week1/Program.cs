﻿// See https://aka.ms/new-console-template for more information
using System;
//web uzantı .exe
namespace MyApp // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}